@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "SL_APP=%~dp0EAC POS v2.5.html"
set "SL_PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%SL_PS%" set "SL_PS=powershell.exe"

if not exist "EAC Server.ps1" goto missing
if not exist "%SL_APP%" goto missing

rem A complete program file is about 1.7 MB. Anything much smaller was not
rem copied fully and would open as unreadable text.
for %%A in ("%SL_APP%") do if %%~zA LSS 500000 goto incomplete

rem If a server is already running, make sure it serves THIS copy and not an
rem old copy left running from another folder.
set "SL_RUNNING="
for /f "usebackq delims=" %%P in (`%SL_PS% -NoProfile -ExecutionPolicy Bypass -Command "$r=$null; try { $r=Invoke-RestMethod 'http://127.0.0.1:17893/api/ping' -TimeoutSec 2 } catch {}; if ($r -and $r.appPath) { $r.appPath }"`) do set "SL_RUNNING=%%P"
if defined SL_RUNNING if /i not "%SL_RUNNING%"=="%SL_APP%" goto othercopy

rem Start the private local server (no console window), then wait until it answers.
start "" /min "%SL_PS%" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0EAC Server.ps1"

"%SL_PS%" -NoProfile -ExecutionPolicy Bypass -Command "$ok=$false; for($i=0;$i -lt 80;$i++){ try { $r=Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:17893/api/ping' -TimeoutSec 1; if($r.StatusCode -eq 200){$ok=$true; break} } catch {}; Start-Sleep -Milliseconds 250 }; if($ok){exit 0}else{exit 1}"
if errorlevel 1 goto failed

rem Open Edge or Chrome directly. The Windows default browser may still be
rem Internet Explorer on some PCs, which cannot run this program.
set "SL_BROWSER="
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "SL_BROWSER=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not defined SL_BROWSER if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "SL_BROWSER=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not defined SL_BROWSER if exist "%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe" set "SL_BROWSER=%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe"
if not defined SL_BROWSER if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "SL_BROWSER=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined SL_BROWSER if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "SL_BROWSER=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not defined SL_BROWSER if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" set "SL_BROWSER=%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"

if defined SL_BROWSER (
  start "" "%SL_BROWSER%" "http://127.0.0.1:17893/"
) else (
  start "" "http://127.0.0.1:17893/"
)
exit /b 0

:missing
echo.
echo EAC files are missing from this folder.
echo Keep ALL the files from the ZIP together, then try again.
echo.
pause
exit /b 1

:incomplete
echo.
echo EAC POS v2.5.html looks incomplete (the file was not copied fully).
echo Extract the ZIP again and keep all the files in one folder.
echo.
pause
exit /b 1

:othercopy
echo.
echo Another copy of EAC is already running from:
echo   %SL_RUNNING%
echo.
echo Close that copy (or restart this PC), then run this file again.
echo.
pause
exit /b 1

:failed
echo.
echo The local server did not start, so the program cannot open.
echo.
echo 1. Close any other copy of EAC.
echo 2. Run this file again.
echo 3. If Windows asks for permission, choose Allow / Yes.
echo.
echo If it still fails, double-click "Check Compatibility.cmd".
echo Technical log: %TEMP%\EAC-server.log
echo.
pause
exit /b 1
