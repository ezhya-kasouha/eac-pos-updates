@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "SL_BASE=%~dp0"
set "SL_SELF=%~f0"
if "%~1"=="" (set "SL_MODE=install") else (set "SL_MODE=%~1")
title EAC - Install Requirements

rem ==========================================================================
rem  EAC POS - Requirements Installer
rem
rem  Double-click this file to check and install everything the program needs.
rem  It only changes what is missing. On Windows 10/11 usually nothing is
rem  needed, so it just checks and opens a readable report.
rem
rem  Modes (optional):
rem    (no argument)  check and install missing components
rem    check          check only, change nothing
rem    prepare        download the official installers for offline use
rem    offline        install only from the Requirements folder, never download
rem ==========================================================================

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$p=$env:SL_SELF; $s=[IO.File]::ReadAllText($p); iex ($s.Substring($s.LastIndexOf('#PSSTART')))"
set "SL_EXIT=%ERRORLEVEL%"
if "%SL_EXIT%"=="3" exit /b 0
echo.
pause
exit /b %SL_EXIT%

#PSSTART
$ErrorActionPreference = 'Continue'

$global:SL_Base = $env:SL_BASE
if (-not $global:SL_Base) { $global:SL_Base = (Get-Location).Path }
$global:SL_Mode = $env:SL_MODE
if (-not $global:SL_Mode) { $global:SL_Mode = 'install' }
$global:SL_NoDownload = ($global:SL_Mode -eq 'offline')
$global:SL_Actions = New-Object System.Collections.ArrayList
$global:SL_Rows = New-Object System.Collections.ArrayList
$global:SL_Restart = $false
$global:SL_Changed = $false

# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
function Add-Action([string]$en, [string]$ar) {
  $o = New-Object PSObject -Property @{ En = $en; Ar = $ar }
  [void]$global:SL_Actions.Add($o)
}

function Add-Row([string]$itemEn, [string]$itemAr, [string]$needEn, [string]$needAr, [string]$found, [string]$state) {
  $o = New-Object PSObject -Property @{
    ItemEn = $itemEn; ItemAr = $itemAr; NeedEn = $needEn; NeedAr = $needAr; Found = $found; State = $state
  }
  [void]$global:SL_Rows.Add($o)
}

function Esc([string]$s) {
  if ($null -eq $s) { return '' }
  return [System.Security.SecurityElement]::Escape($s)
}

function Write-Head([string]$text) {
  Write-Host ''
  Write-Host $text
  Write-Host ('-' * $text.Length)
}

function Get-NetRelease {
  $rel = 0
  try {
    $rel = [int](Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -Name Release -ErrorAction Stop).Release
  } catch { }
  return $rel
}

function Get-NetName([int]$rel) {
  if ($rel -ge 533320) { return '4.8.1 or newer' }
  if ($rel -ge 528040) { return '4.8' }
  if ($rel -ge 461808) { return '4.7.2' }
  if ($rel -ge 460798) { return '4.7' }
  if ($rel -ge 394802) { return '4.6.2' }
  if ($rel -ge 393295) { return '4.6' }
  if ($rel -ge 379893) { return '4.5.2' }
  if ($rel -ge 378675) { return '4.5.1' }
  if ($rel -ge 378389) { return '4.5' }
  if ($rel -gt 0) { return "older (release $rel)" }
  return 'not found'
}

function Test-WshEnabled {
  $paths = @(
    'HKLM:\SOFTWARE\Microsoft\Windows Script Host\Settings',
    'HKCU:\SOFTWARE\Microsoft\Windows Script Host\Settings'
  )
  foreach ($p in $paths) {
    if (Test-Path -LiteralPath $p) {
      $v = (Get-ItemProperty -Path $p -Name Enabled -ErrorAction SilentlyContinue).Enabled
      if ($null -ne $v -and [int]$v -eq 0) { return $false }
    }
  }
  return $true
}

function Enable-Wsh {
  $paths = @(
    'HKLM:\SOFTWARE\Microsoft\Windows Script Host\Settings',
    'HKCU:\SOFTWARE\Microsoft\Windows Script Host\Settings'
  )
  foreach ($p in $paths) {
    try {
      if (-not (Test-Path -LiteralPath $p)) { New-Item -Path $p -Force | Out-Null }
      New-ItemProperty -Path $p -Name Enabled -Value 1 -PropertyType DWord -Force | Out-Null
    } catch { }
  }
  $global:SL_Changed = $true
  Add-Action 'Windows Script Host enabled.' 'تم تمكين Windows Script Host.'
}

function Get-BrowserInfo {
  $cands = New-Object System.Collections.ArrayList
  $pf = $env:ProgramFiles
  $pf86 = ${env:ProgramFiles(x86)}
  $lad = $env:LOCALAPPDATA
  if ($pf) {
    [void]$cands.Add(@{ Name = 'Microsoft Edge'; Path = (Join-Path $pf 'Microsoft\Edge\Application\msedge.exe') })
    [void]$cands.Add(@{ Name = 'Google Chrome'; Path = (Join-Path $pf 'Google\Chrome\Application\chrome.exe') })
  }
  if ($pf86) {
    [void]$cands.Add(@{ Name = 'Microsoft Edge'; Path = (Join-Path $pf86 'Microsoft\Edge\Application\msedge.exe') })
    [void]$cands.Add(@{ Name = 'Google Chrome'; Path = (Join-Path $pf86 'Google\Chrome\Application\chrome.exe') })
  }
  if ($lad) {
    [void]$cands.Add(@{ Name = 'Google Chrome'; Path = (Join-Path $lad 'Google\Chrome\Application\chrome.exe') })
  }
  foreach ($c in $cands) {
    if (Test-Path -LiteralPath $c.Path) {
      $v = ''
      try { $v = (Get-Item -LiteralPath $c.Path).VersionInfo.ProductVersion } catch { }
      if ($v) {
        return (New-Object PSObject -Property @{ Name = $c.Name; Version = $v; Path = $c.Path })
      }
    }
  }
  return $null
}

function Get-RequirementFile([string]$name) {
  $p1 = Join-Path (Join-Path $global:SL_Base 'Requirements') $name
  if (Test-Path -LiteralPath $p1) { return $p1 }
  $p2 = Join-Path $global:SL_Base $name
  if (Test-Path -LiteralPath $p2) { return $p2 }
  return $null
}

function Save-Download([string]$url, [string]$dest) {
  $dir = Split-Path -Parent $dest
  if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
  Write-Host ("Downloading {0} ..." -f (Split-Path -Leaf $dest))
  try {
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }
    $wc = New-Object System.Net.WebClient
    $wc.Headers.Add('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)')
    $wc.DownloadFile($url, $dest)
    if ((Test-Path -LiteralPath $dest) -and ((Get-Item -LiteralPath $dest).Length -gt 100000)) {
      Write-Host ("  saved {0:N1} MB" -f ((Get-Item -LiteralPath $dest).Length / 1MB))
      return $true
    }
    return $false
  } catch {
    Write-Host ("  download failed: {0}" -f $_.Exception.Message)
    if (Test-Path -LiteralPath $dest) { Remove-Item -LiteralPath $dest -Force -ErrorAction SilentlyContinue }
    return $false
  }
}

function Ensure-File([string]$name, [string]$url) {
  $local = Get-RequirementFile $name
  if ($local) { return $local }
  if ($global:SL_NoDownload) {
    Add-Action ("Missing offline file: " + $name) ("ملف أوفلاين مفقود: " + $name)
    return $null
  }
  $dest = Join-Path (Join-Path $global:SL_Base 'Requirements') $name
  if (Save-Download $url $dest) { return $dest }
  return $null
}

function Install-DotNet48 {
  $exe = Ensure-File 'NDP48-x86-x64-AllOS-ENU.exe' 'https://go.microsoft.com/fwlink/?linkid=2088631'
  if (-not $exe) { return $false }
  Write-Host 'Installing .NET Framework 4.8 (this can take several minutes) ...'
  $code = 1
  try {
    $p = Start-Process -FilePath $exe -ArgumentList '/quiet', '/norestart' -Wait -PassThru
    if ($p) { $code = $p.ExitCode }
  } catch {
    Write-Host ('  could not start the installer: ' + $_.Exception.Message)
  }
  Write-Host ("  exit code: {0}" -f $code)
  if ($code -eq 0 -or $code -eq 1641 -or $code -eq 3010 -or $code -eq 5100) {
    if ($code -eq 1641 -or $code -eq 3010) { $global:SL_Restart = $true }
    $global:SL_Changed = $true
    Add-Action '.NET Framework 4.8 installed.' 'تم تثبيت .NET Framework 4.8.'
    return $true
  }
  Add-Action (".NET Framework 4.8 installer returned code " + $code + ".") ("أعاد مثبّت .NET Framework 4.8 الرمز " + $code + ".")
  return $false
}

function Install-Wmf51 {
  if ($global:SL_PSMajor -ge 5) { return $true }
  if ($global:SL_Build -eq 9200) {
    Add-Action 'Windows 8.0 cannot install PowerShell 5.1; Windows 8.1 or newer is required.' 'لا يمكن تثبيت PowerShell 5.1 على Windows 8.0؛ يلزم Windows 8.1 أو أحدث.'
    return $false
  }
  $url = ''
  $name = ''
  $isZip = $false
  if ($global:SL_Build -eq 9600) {
    if ($global:SL_Is64) {
      $name = 'Win8.1AndW2K12R2-KB3191564-x64.msu'
      $url = 'https://go.microsoft.com/fwlink/?linkid=839516'
    } else {
      $name = 'Win8.1-KB3191564-x86.msu'
      $url = 'https://go.microsoft.com/fwlink/?linkid=839521'
    }
  } elseif ($global:SL_Build -eq 7600 -or $global:SL_Build -eq 7601) {
    $isZip = $true
    if ($global:SL_Is64) {
      $name = 'Win7AndW2K8R2-KB3191566-x64.zip'
      $url = 'https://go.microsoft.com/fwlink/?linkid=839523'
    } else {
      $name = 'Win7-KB3191566-x86.zip'
      $url = 'https://go.microsoft.com/fwlink/?linkid=839522'
    }
  } else {
    Add-Action 'PowerShell 5.1 is not available for this Windows version.' 'PowerShell 5.1 غير متوفر لهذا الإصدار من ويندوز.'
    return $false
  }

  $pkg = Ensure-File $name $url
  if (-not $pkg) { return $false }

  $tmp = Join-Path $env:TEMP ('sl_wmf_' + [Guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $tmp -Force | Out-Null
  $msus = @()

  if ($isZip) {
    Write-Host 'Extracting PowerShell 5.1 package ...'
    try {
      $shell = New-Object -ComObject Shell.Application
      $zipNs = $shell.NameSpace($pkg)
      $destNs = $shell.NameSpace($tmp)
      if ($zipNs -and $destNs) { $destNs.CopyHere($zipNs.Items(), 0x14) }
      for ($i = 0; $i -lt 60; $i++) {
        $msus = @(Get-ChildItem -LiteralPath $tmp -Filter *.msu -Recurse)
        if ($msus.Count -gt 0) { break }
        Start-Sleep -Milliseconds 500
      }
    } catch {
      Write-Host ('  could not extract the package: ' + $_.Exception.Message)
    }
  } else {
    $msus = @(Get-Item -LiteralPath $pkg)
  }

  if ($msus.Count -eq 0) {
    Add-Action 'PowerShell 5.1 package did not contain an installer.' 'حزمة PowerShell 5.1 لا تحتوي على مثبّت.'
    return $false
  }

  $ok = $false
  foreach ($m in $msus) {
    Write-Host ("Installing {0} ..." -f $m.Name)
    $code = 1
    try {
      $wusa = Join-Path $env:WINDIR 'System32\wusa.exe'
      $p = Start-Process -FilePath $wusa -ArgumentList ('"' + $m.FullName + '"'), '/quiet', '/norestart' -Wait -PassThru
      if ($p) { $code = $p.ExitCode }
    } catch {
      Write-Host ('  could not start wusa: ' + $_.Exception.Message)
    }
    Write-Host ("  exit code: {0}" -f $code)
    if ($code -eq 0 -or $code -eq 3010 -or $code -eq 2359302) {
      if ($code -eq 3010) { $global:SL_Restart = $true }
      $ok = $true
    }
  }

  if ($ok) {
    $global:SL_Changed = $true
    $global:SL_Restart = $true
    Add-Action 'PowerShell 5.1 installed. Restart the PC to finish.' 'تم تثبيت PowerShell 5.1. أعد تشغيل الكمبيوتر لإكمال التثبيت.'
    return $true
  }
  Add-Action 'PowerShell 5.1 installation did not complete.' 'لم يكتمل تثبيت PowerShell 5.1.'
  return $false
}

function Test-EACPing {
  try {
    $wc = New-Object System.Net.WebClient
    $wc.Proxy = $null
    $data = $wc.DownloadString('http://127.0.0.1:17893/api/ping')
    if ($data -match 'EAC') { return $true }
  } catch { }
  return $false
}

function Test-PortOpen {
  $client = New-Object System.Net.Sockets.TcpClient
  try {
    $iar = $client.BeginConnect('127.0.0.1', 17893, $null, $null)
    if ($iar.AsyncWaitHandle.WaitOne(700)) {
      $client.EndConnect($iar)
      return $true
    }
  } catch { }
  finally {
    try { $client.Close() } catch { }
  }
  return $false
}

# ---------------------------------------------------------------------------
# prepare mode: download the official installers for offline use
# ---------------------------------------------------------------------------
if ($global:SL_Mode -eq 'prepare') {
  Write-Head 'EAC - Preparing offline requirements'
  $dir = Join-Path $global:SL_Base 'Requirements'
  New-Item -ItemType Directory -Path $dir -Force | Out-Null
  $items = @(
    @{ Name = 'NDP48-x86-x64-AllOS-ENU.exe'; Url = 'https://go.microsoft.com/fwlink/?linkid=2088631' },
    @{ Name = 'Win8.1AndW2K12R2-KB3191564-x64.msu'; Url = 'https://go.microsoft.com/fwlink/?linkid=839516' },
    @{ Name = 'Win8.1-KB3191564-x86.msu'; Url = 'https://go.microsoft.com/fwlink/?linkid=839521' },
    @{ Name = 'Win7AndW2K8R2-KB3191566-x64.zip'; Url = 'https://go.microsoft.com/fwlink/?linkid=839523' },
    @{ Name = 'Win7-KB3191566-x86.zip'; Url = 'https://go.microsoft.com/fwlink/?linkid=839522' }
  )
  $okCount = 0
  foreach ($it in $items) {
    $dest = Join-Path $dir $it.Name
    if (Test-Path -LiteralPath $dest) {
      Write-Host ("Already present: {0}" -f $it.Name)
      $okCount = $okCount + 1
      continue
    }
    if (Save-Download $it.Url $dest) { $okCount = $okCount + 1 }
  }
  Write-Host ''
  Write-Host ("Ready: {0} of {1} files in {2}" -f $okCount, $items.Count, $dir)
  if ($okCount -eq $items.Count) {
    Write-Host 'Copy this whole folder and the installer to the other PC, then run it with: offline'
    exit 0
  }
  Write-Host 'Some files could not be downloaded. Check the internet connection and run prepare again.'
  exit 1
}

# ---------------------------------------------------------------------------
# collect information
# ---------------------------------------------------------------------------
$global:SL_Build = 0
try {
  $global:SL_Build = [int](Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -Name CurrentBuildNumber -ErrorAction Stop).CurrentBuildNumber
} catch { }

$global:SL_Is64 = ([IntPtr]::Size -eq 8)
$global:SL_Arch = '32-bit'
if ($global:SL_Is64) { $global:SL_Arch = '64-bit' }

$global:SL_WinName = 'Windows'
if ($global:SL_Build -ge 22000) { $global:SL_WinName = 'Windows 11' }
elseif ($global:SL_Build -ge 10240) { $global:SL_WinName = 'Windows 10' }
elseif ($global:SL_Build -eq 9600) { $global:SL_WinName = 'Windows 8.1' }
elseif ($global:SL_Build -eq 9200) { $global:SL_WinName = 'Windows 8' }
elseif ($global:SL_Build -eq 7601) { $global:SL_WinName = 'Windows 7 SP1' }
elseif ($global:SL_Build -eq 7600) { $global:SL_WinName = 'Windows 7' }

$global:SL_PS = $PSVersionTable.PSVersion
$global:SL_PSMajor = [int]$global:SL_PS.Major
$global:SL_PSMinor = [int]$global:SL_PS.Minor

$global:SL_NetRel = Get-NetRelease
$global:SL_WshOk = Test-WshEnabled

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
$isAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

$needInstall = $false
if ($global:SL_NetRel -lt 378389) { $needInstall = $true }
if ($global:SL_PSMajor -lt 5) { $needInstall = $true }
if (-not $global:SL_WshOk) { $needInstall = $true }

# ---------------------------------------------------------------------------
# install mode: ask for administrator rights only when something is missing
# ---------------------------------------------------------------------------
if ($global:SL_Mode -eq 'install' -and $needInstall -and -not $isAdmin) {
  Write-Host ''
  Write-Host 'Administrator permission is required to install the missing components.'
  Write-Host 'A Windows prompt will appear. Choose Yes.'
  try {
    Start-Process -FilePath $env:ComSpec -ArgumentList '/c', ('"' + $env:SL_SELF + '" install-child') -Verb RunAs
    exit 3
  } catch {
    Write-Host ('Could not request administrator permission: ' + $_.Exception.Message)
  }
}

Write-Head 'EAC - Requirements Check'
Write-Host ("Mode: {0}" -f $global:SL_Mode)
Write-Host ("Computer: {0} ({1})" -f $env:COMPUTERNAME, $global:SL_Arch)

if ($global:SL_Mode -ne 'check') {
  if ($global:SL_NetRel -lt 378389) { [void](Install-DotNet48) }
  if ($global:SL_PSMajor -lt 5) { [void](Install-Wmf51) }
  if (-not (Test-WshEnabled)) { Enable-Wsh }
}

# re-read what can change without a restart
$global:SL_NetRel = Get-NetRelease
$global:SL_WshOk = Test-WshEnabled
$browser = Get-BrowserInfo

# ---------------------------------------------------------------------------
# find the program files (this tool may be run from the package or the Desktop)
# ---------------------------------------------------------------------------
$appBase = $global:SL_Base
$htmlName = 'EAC POS v2.3.html'
# If the program is already running, the server reports the exact folder.
if (-not (Test-Path -LiteralPath (Join-Path $appBase $htmlName))) {
  try {
    $wcPing = New-Object System.Net.WebClient
    $wcPing.Proxy = $null
    $pingJson = $wcPing.DownloadString('http://127.0.0.1:17893/api/ping')
    $pm = [regex]::Match($pingJson, '"appPath"\s*:\s*"([^"]+)"')
    if ($pm.Success) {
      $runningHtml = $pm.Groups[1].Value -replace '\\\\', '\' -replace '\\/', '/'
      if (Test-Path -LiteralPath $runningHtml) { $appBase = Split-Path -Parent $runningHtml }
    }
  } catch { }
}
if (-not (Test-Path -LiteralPath (Join-Path $appBase $htmlName))) {
  $alt1 = Join-Path $global:SL_Base 'EAC Customer Package v2'
  if (Test-Path -LiteralPath (Join-Path $alt1 $htmlName)) { $appBase = $alt1 }
}
if (-not (Test-Path -LiteralPath (Join-Path $appBase $htmlName))) {
  $alt2 = Join-Path (Join-Path $env:USERPROFILE 'Desktop') 'EAC Customer Package v2'
  if (Test-Path -LiteralPath (Join-Path $alt2 $htmlName)) { $appBase = $alt2 }
}
$htmlPath = Join-Path $appBase $htmlName
$htmlSize = 0
if (Test-Path -LiteralPath $htmlPath) { $htmlSize = (Get-Item -LiteralPath $htmlPath).Length }
$serverOk = Test-Path -LiteralPath (Join-Path $appBase 'EAC Server.ps1')
$relayOk = Test-Path -LiteralPath (Join-Path $appBase 'EAC Telegram Relay.ps1')
$launcherCmdOk = Test-Path -LiteralPath (Join-Path $appBase 'EAC Launcher.cmd')
$launcherVbsOk = Test-Path -LiteralPath (Join-Path $appBase 'EAC Launcher.vbs')
$launcherDataOk = Test-Path -LiteralPath (Join-Path $appBase 'EAC Launcher.vbs.dat')
$launcherOk = $launcherCmdOk -and ($launcherVbsOk -or $launcherDataOk)
$backupOk = Test-Path -LiteralPath (Join-Path $appBase 'EAC Launcher (backup).cmd')
$repairOk = Test-Path -LiteralPath (Join-Path $appBase 'EAC Repair.cmd')

# ---------------------------------------------------------------------------
# build the report rows
# ---------------------------------------------------------------------------
if ($global:SL_Build -ge 10240) {
  Add-Row 'Windows' 'نظام ويندوز' 'Windows 10 or 11' 'ويندوز 10 أو 11' ("$($global:SL_WinName) ($($global:SL_Arch)) - build $($global:SL_Build)") 'ok'
} elseif ($global:SL_Build -ge 9600) {
  Add-Row 'Windows' 'نظام ويندوز' 'Windows 10 or 11' 'ويندوز 10 أو 11' ("$($global:SL_WinName) ($($global:SL_Arch)) - build $($global:SL_Build)") 'warn'
} else {
  Add-Row 'Windows' 'نظام ويندوز' 'Windows 10 or 11' 'ويندوز 10 أو 11' ("$($global:SL_WinName) ($($global:SL_Arch)) - build $($global:SL_Build)") 'fail'
}

$psFound = "$($global:SL_PS) (Desktop edition)"
if ($global:SL_PSMajor -gt 5 -or ($global:SL_PSMajor -eq 5 -and $global:SL_PSMinor -ge 1)) {
  Add-Row 'PowerShell' 'PowerShell' '5.1 or newer' '5.1 أو أحدث' $psFound 'ok'
} elseif ($global:SL_PSMajor -ge 3) {
  Add-Row 'PowerShell' 'PowerShell' '5.1 or newer' '5.1 أو أحدث' $psFound 'warn'
} else {
  Add-Row 'PowerShell' 'PowerShell' '5.1 or newer' '5.1 أو أحدث' $psFound 'fail'
}

$netFound = "$(Get-NetName $global:SL_NetRel) (release $($global:SL_NetRel))"
if ($global:SL_NetRel -ge 378389) {
  Add-Row '.NET Framework' '.NET Framework' '4.5 or newer' '4.5 أو أحدث' $netFound 'ok'
} else {
  Add-Row '.NET Framework' '.NET Framework' '4.5 or newer' '4.5 أو أحدث' $netFound 'fail'
}

if ($global:SL_WshOk) {
  Add-Row 'Windows Script Host' 'Windows Script Host' 'Enabled (built in)' 'ممكّن (مدمج)' 'cscript.exe present and enabled' 'ok'
} else {
  Add-Row 'Windows Script Host' 'Windows Script Host' 'Enabled (built in)' 'ممكّن (مدمج)' 'Disabled by policy or settings' 'fail'
}

if ($browser) {
  $browserMajor = 0
  try { $browserMajor = [int](($browser.Version -split '\.')[0]) } catch { }
  $browserFound = "$($browser.Name) $($browser.Version)"
  if ($browserMajor -ge 105) {
    Add-Row 'Browser' 'المتصفح' 'Edge/Chrome 105 or newer' 'Edge/Chrome 105 أو أحدث' $browserFound 'ok'
  } elseif ($browserMajor -ge 80) {
    Add-Row 'Browser' 'المتصفح' 'Edge/Chrome 105 or newer' 'Edge/Chrome 105 أو أحدث' $browserFound 'warn'
  } else {
    Add-Row 'Browser' 'المتصفح' 'Edge/Chrome 105 or newer' 'Edge/Chrome 105 أو أحدث' $browserFound 'fail'
  }
} else {
  Add-Row 'Browser' 'المتصفح' 'Edge/Chrome 105 or newer' 'Edge/Chrome 105 أو أحدث' 'No Microsoft Edge or Google Chrome found' 'fail'
}

if ($htmlSize -ge 500000 -and $serverOk -and $relayOk -and $launcherOk -and $backupOk -and $repairOk) {
  Add-Row 'Program files' 'ملفات البرنامج' 'All required program files together' 'كل ملفات البرنامج المطلوبة معاً' ("HTML: {0:N2} MB; Server: yes; Relay: yes; Launcher: yes; Backup: yes; Repair: yes" -f ($htmlSize / 1MB)) 'ok'
} elseif ($htmlSize -gt 0 -or $serverOk -or $relayOk -or $launcherOk -or $backupOk -or $repairOk) {
  Add-Row 'Program files' 'ملفات البرنامج' 'All required program files together' 'كل ملفات البرنامج المطلوبة معاً' ("HTML: {0:N2} MB; Server: {1}; Relay: {2}; Launcher: {3}; Backup: {4}; Repair: {5}" -f ($htmlSize / 1MB), $serverOk, $relayOk, $launcherOk, $backupOk, $repairOk) 'fail'
} else {
  Add-Row 'Program files' 'ملفات البرنامج' 'All required program files together' 'كل ملفات البرنامج المطلوبة معاً' 'Program files not found in this folder' 'warn'
}

if (Test-EACPing) {
  Add-Row 'Port 17893' 'المنفذ 17893' 'Free, or used by EAC' 'حر أو مستخدم بواسطة EAC' 'EAC server is already running on 17893' 'ok'
} elseif (Test-PortOpen) {
  Add-Row 'Port 17893' 'المنفذ 17893' 'Free, or used by EAC' 'حر أو مستخدم بواسطة EAC' 'Port 17893 is used by another program' 'warn'
} else {
  Add-Row 'Port 17893' 'المنفذ 17893' 'Free, or used by EAC' 'حر أو مستخدم بواسطة EAC' 'Port 17893 is free' 'ok'
}

# optional devices
$camCount = 0
try {
  $cams = @(Get-WmiObject Win32_PnPEntity -Filter "PNPClass='Camera'" -ErrorAction SilentlyContinue)
  $camCount = $cams.Count
} catch { }
if ($camCount -gt 0) {
  Add-Row 'Camera (optional)' 'الكاميرا (اختياري)' 'Only for QR scanning' 'لقارئ QR فقط' ("$camCount camera(s) detected") 'ok'
} else {
  Add-Row 'Camera (optional)' 'الكاميرا (اختياري)' 'Only for QR scanning' 'لقارئ QR فقط' 'No camera detected' 'warn'
}

$prnCount = 0
try {
  $prns = @(Get-WmiObject Win32_Printer -ErrorAction SilentlyContinue)
  $prnCount = $prns.Count
} catch { }
if ($prnCount -gt 0) {
  Add-Row 'Printer (optional)' 'الطابعة (اختياري)' 'Only for printing' 'للطباعة فقط' ("$prnCount printer(s) detected") 'ok'
} else {
  Add-Row 'Printer (optional)' 'الطابعة (اختياري)' 'Only for printing' 'للطباعة فقط' 'No printer detected' 'warn'
}

# ---------------------------------------------------------------------------
# verdict
# ---------------------------------------------------------------------------
$fails = 0
$warns = 0
foreach ($r in $global:SL_Rows) {
  if ($r.ItemEn -match 'optional') { continue }
  if ($r.State -eq 'fail') { $fails = $fails + 1 }
  if ($r.State -eq 'warn') { $warns = $warns + 1 }
}

$verdictEn = 'This PC has everything EAC needs. Start the program with EAC Launcher.cmd.'
$verdictAr = 'هذا الجهاز يحتوي على كل ما يحتاجه EAC. شغّل البرنامج من EAC Launcher.cmd.'
$verdictClass = 'ok'
if ($fails -gt 0) {
  $verdictEn = 'This PC is NOT ready yet. See the red rows and the actions below.'
  $verdictAr = 'هذا الجهاز غير جاهز بعد. راجع البنود الحمراء والإجراءات أدناه.'
  $verdictClass = 'fail'
} elseif ($warns -gt 0) {
  $verdictEn = 'This PC should work, with warnings. See the yellow rows below.'
  $verdictAr = 'من المفترض أن يعمل الجهاز مع بعض الملاحظات. راجع البنود الصفراء أدناه.'
  $verdictClass = 'warn'
}

# ---------------------------------------------------------------------------
# console summary
# ---------------------------------------------------------------------------
foreach ($r in $global:SL_Rows) {
  Write-Host ("[{0}] {1}: {2}" -f $r.State.ToUpper(), $r.ItemEn, $r.Found)
}
Write-Host ''
if ($global:SL_Actions.Count -gt 0) {
  Write-Host 'Actions taken:'
  foreach ($a in $global:SL_Actions) { Write-Host ('  - ' + $a.En) }
  Write-Host ''
}
Write-Host $verdictEn
if ($global:SL_Restart) {
  Write-Host 'A restart is required to finish installing the missing components.'
}
Write-Host 'The Arabic result is shown in the report that opens in your browser.'

# ---------------------------------------------------------------------------
# bilingual HTML report
# ---------------------------------------------------------------------------
$badge = @{
  ok = '<span class="b ok">OK</span>'
  warn = '<span class="b warn">WARN</span>'
  fail = '<span class="b fail">FAIL</span>'
}

$rowHtml = ''
foreach ($r in $global:SL_Rows) {
  $rowHtml = $rowHtml + '<tr><td class="item"><div class="en">' + (Esc $r.ItemEn) + '</div><div class="ar">' + (Esc $r.ItemAr) + '</div></td>' +
    '<td><div class="en">' + (Esc $r.NeedEn) + '</div><div class="ar">' + (Esc $r.NeedAr) + '</div></td>' +
    '<td class="found">' + (Esc $r.Found) + '</td>' +
    '<td class="st">' + $badge[$r.State] + '</td></tr>'
}

$actionHtml = ''
if ($global:SL_Actions.Count -gt 0) {
  $actionHtml = '<div class="actions"><b>Actions taken / الإجراءات المنفذة:</b><ul>'
  foreach ($a in $global:SL_Actions) {
    $actionHtml = $actionHtml + '<li><div class="en">' + (Esc $a.En) + '</div><div class="ar">' + (Esc $a.Ar) + '</div></li>'
  }
  $actionHtml = $actionHtml + '</ul></div>'
}

$restartHtml = ''
if ($global:SL_Restart) {
  $restartHtml = '<div class="restart"><b>Restart required / مطلوب إعادة تشغيل:</b><br>Restart the PC, then run the compatibility check again. / أعد تشغيل الكمبيوتر ثم شغّل فحص التوافق مرة أخرى.</div>'
}

$now = Get-Date -Format 'yyyy-MM-dd HH:mm'
$pc = $env:COMPUTERNAME

$html = @"
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>EAC POS - المتطلبات / Requirements</title>
<style>
  body { margin:0; padding:24px; background:#0f172a; color:#e2e8f0; font-family:'Segoe UI',Tahoma,Arial,sans-serif; }
  .wrap { max-width:1000px; margin:0 auto; }
  h1 { font-size:24px; margin:0 0 6px; color:#fff; }
  .sub { color:#94a3b8; font-size:13px; margin-bottom:20px; }
  .verdict { border-radius:16px; padding:18px 20px; margin-bottom:18px; border:1px solid; }
  .verdict.ok { background:#052e1b; border-color:#166534; }
  .verdict.warn { background:#3b2a05; border-color:#a16207; }
  .verdict.fail { background:#3b0a0a; border-color:#b91c1c; }
  .verdict .en { font-size:17px; font-weight:800; color:#fff; }
  .verdict .ar { font-size:16px; font-weight:700; margin-top:6px; }
  table { width:100%; border-collapse:collapse; background:#111c33; border-radius:14px; overflow:hidden; }
  th, td { padding:12px 14px; border-bottom:1px solid #1e2d4d; text-align:start; vertical-align:top; }
  th { background:#16233d; color:#93c5fd; font-size:12px; text-transform:uppercase; letter-spacing:.4px; }
  td { font-size:13px; }
  .item .en, td .en { font-weight:700; color:#fff; }
  .item .ar, td .ar { color:#94a3b8; font-size:12px; margin-top:2px; }
  .found { font-family:Consolas,monospace; font-size:12px; color:#cbd5e1; word-break:break-word; }
  .st { text-align:center; white-space:nowrap; }
  .b { display:inline-block; padding:3px 10px; border-radius:999px; font-size:11px; font-weight:800; }
  .b.ok { background:#052e1b; color:#4ade80; border:1px solid #166534; }
  .b.warn { background:#3b2a05; color:#facc15; border:1px solid #a16207; }
  .b.fail { background:#3b0a0a; color:#f87171; border:1px solid #b91c1c; }
  .actions, .restart { margin-top:18px; padding:14px 16px; border-radius:12px; background:#111c33; border:1px solid #1e2d4d; font-size:12px; line-height:1.9; color:#cbd5e1; }
  .actions b, .restart b { color:#fff; }
  .actions ul { margin:8px 0 0; padding-inline-start:20px; }
  .actions li { margin-bottom:6px; }
  .actions li .ar { color:#94a3b8; }
  .restart { background:#3b2a05; border-color:#a16207; color:#fde68a; }
  .note { margin-top:18px; padding:14px 16px; border-radius:12px; background:#111c33; border:1px solid #1e2d4d; font-size:12px; line-height:1.9; color:#cbd5e1; }
  .note b { color:#fff; }
  .foot { margin-top:14px; color:#64748b; font-size:11px; text-align:center; }
  @media print { body { background:#fff; color:#0f172a; } table { background:#fff; } th { background:#f1f5f9; color:#0f172a; } td { border-color:#e2e8f0; } .verdict .en, .verdict .ar, .item .en, td .en { color:#0f172a; } .note, .actions { background:#f8fafc; border-color:#e2e8f0; color:#334155; } }
</style>
</head>
<body>
<div class="wrap">
  <h1>EAC POS - المتطلبات</h1>
  <div class="sub">Requirements Check &nbsp;|&nbsp; $now &nbsp;|&nbsp; $pc</div>

  <div class="verdict $verdictClass">
    <div class="en">$(Esc $verdictEn)</div>
    <div class="ar">$(Esc $verdictAr)</div>
  </div>

  <table>
    <thead><tr><th>Item / البند</th><th>Required / المطلوب</th><th>Found on this PC / الموجود</th><th>Status</th></tr></thead>
    <tbody>$rowHtml</tbody>
  </table>

  $actionHtml
  $restartHtml

  <div class="note">
    <b>ملاحظات مهمة / Important:</b><br>
    • البرنامج لا يحتاج إنترنت ولا أي مكتبات خارجية. / The program needs no internet and no external libraries.<br>
    • كل جهاز جديد يحتاج كود تفعيل جديداً. / A new PC needs a new activation code.<br>
    • إذا كان البند أصفر (WARN) فعادةً يعمل البرنامج، لكن يُفضّل تحديث المتصفح أو ويندوز.<br>
    • If a row is yellow (WARN) the program usually works, but updating the browser or Windows is recommended.
  </div>
  <div class="foot">EAC POS v2 - requirements report</div>
</div>
</body>
</html>
"@

$report = Join-Path $env:TEMP 'EAC Requirements Report.html'
[System.IO.File]::WriteAllText($report, $html, (New-Object System.Text.UTF8Encoding($true)))
Write-Host ''
Write-Host ("Report: " + $report)
try { Start-Process $report } catch { Write-Host 'Open the report above in your browser.' }

if ($fails -gt 0) { exit 1 }
if ($global:SL_Restart) { exit 2 }
exit 0
