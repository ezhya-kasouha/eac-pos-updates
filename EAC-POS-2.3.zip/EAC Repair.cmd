@echo off
setlocal
cd /d "%~dp0"
rem ==========================================================================
rem  EAC POS - Repair / إصلاح
rem  Fixes the launcher if it was damaged while copying or re-saving.
rem  A damaged launcher shows: Windows Script Host error at Line 1.
rem  It does not touch shop data or activation.
rem  Double-click this file, then start the program again.
rem ==========================================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$p='%~f0'; $s=[IO.File]::ReadAllText($p); iex ($s.Substring($s.LastIndexOf('#PSSTART')))"
if errorlevel 1 (
  echo.
  echo The repair tool could not run. PowerShell may be blocked.
  echo Try this instead:  EAC Launcher ^(backup^).cmd
  echo.
  pause
)
exit /b

#LAUNCHER-BEGIN
' ============================================================================
'  EAC POS - silent launcher
'  Starts the local server with NO console window, then opens the program
'  in Microsoft Edge or Google Chrome (not in an old default browser).
'  Double-click this file. Keep it in the same folder as the other files.
' ============================================================================
Option Explicit

Const SERVER_BUILD = "9"

Dim fso, sh, base, serverPs1, appHtml, url, i, logFile, up, appSize
Dim psExe, psMajor, browser, pingReply, needRestart, stalePath

Set fso = CreateObject("Scripting.FileSystemObject")
Set sh  = CreateObject("WScript.Shell")

base      = fso.GetParentFolderName(WScript.ScriptFullName)
serverPs1 = fso.BuildPath(base, "EAC Server.ps1")
appHtml   = fso.BuildPath(base, "EAC POS v2.3.html")
url       = "http://127.0.0.1:17893/"
logFile   = fso.BuildPath(sh.ExpandEnvironmentStrings("%TEMP%"), "EAC-launcher.log")

' Use the full path to Windows PowerShell. This works even when the PATH is
' damaged or PowerShell is not registered in the environment.
psExe = fso.BuildPath(sh.ExpandEnvironmentStrings("%SystemRoot%"), "System32\WindowsPowerShell\v1.0\powershell.exe")
If Not fso.FileExists(psExe) Then psExe = "powershell.exe"

Log "launcher start; base=" & base

If Not fso.FileExists(serverPs1) Then
  Log "ERROR: server script missing"
  MsgBox "EAC Server.ps1 was not found next to this launcher." & vbCrLf & vbCrLf & _
         "Keep all the files together in the same folder, then try again.", _
         vbCritical, "EAC POS"
  WScript.Quit 1
End If

' The program file must exist and be complete. A missing or half-copied
' file is the usual reason a moved copy shows only unreadable text.
If Not fso.FileExists(appHtml) Then
  Log "ERROR: program file missing"
  MsgBox "EAC POS v2.3.html was not found in this folder." & vbCrLf & vbCrLf & _
         "Copy ALL the files from the ZIP together, then try again.", _
         vbCritical, "EAC POS"
  WScript.Quit 1
End If

appSize = fso.GetFile(appHtml).Size
If appSize < 500000 Then
  Log "ERROR: program file incomplete; size=" & appSize
  MsgBox "EAC POS v2.3.html looks incomplete (only " & appSize & " bytes)." & vbCrLf & vbCrLf & _
         "The file was not copied completely. Extract the ZIP again and keep" & vbCrLf & _
         "all the files together in one folder.", _
         vbCritical, "EAC POS"
  WScript.Quit 1
End If

' The server needs PowerShell 3.0 or newer. Windows 10/11 already has 5.1.
psMajor = GetPsMajor()
Log "powershell major=" & psMajor
If psMajor > 0 And psMajor < 3 Then
  Log "ERROR: PowerShell too old"
  MsgBox "This PC has an old version of PowerShell (" & psMajor & ")." & vbCrLf & vbCrLf & _
         "EAC needs PowerShell 3.0 or newer (5.1 is recommended)." & vbCrLf & vbCrLf & _
         "1. Double-click ""EAC Install Requirements.cmd""." & vbCrLf & _
         "2. Choose Yes if Windows asks for permission." & vbCrLf & _
         "3. Restart the PC, then double-click this launcher again.", _
         vbExclamation, "EAC POS"
  WScript.Quit 1
End If

' Reuse a running server only if it is the same version AND serves THIS copy.
' An old server left running from another folder is the usual reason the
' browser opens a wrong or missing page even though the HTML file is fine.
pingReply = GetPing()
needRestart = False
stalePath = ""

If pingReply <> "" Then
  Log "server already running"
  If JsonString(pingReply, "build") <> SERVER_BUILD Then
    Log "old server build=" & JsonString(pingReply, "build") & "; will restart it"
    needRestart = True
  End If
  stalePath = JsonString(pingReply, "appPath")
  If stalePath <> "" Then
    If StrComp(NormPath(stalePath), NormPath(appHtml), vbTextCompare) <> 0 Then
      Log "server serves another copy: " & stalePath
      needRestart = True
    End If
  End If

  If needRestart Then
    If StopServer() Then
      For i = 1 To 40
        If GetPing() = "" Then Exit For
        WScript.Sleep 250
      Next
      Log "old server stopped"
    Else
      Log "ERROR: the old server cannot be stopped automatically"
      MsgBox "An older copy of EAC is running from:" & vbCrLf & _
             stalePath & vbCrLf & vbCrLf & _
             "Restart this PC once, then double-click this launcher again." & vbCrLf & _
             "Your data and activation are safe.", _
             vbExclamation, "EAC POS"
      WScript.Quit 1
    End If

    If GetPing() <> "" Then
      Log "ERROR: could not stop the old server"
      MsgBox "Another copy of EAC is already running from:" & vbCrLf & _
             stalePath & vbCrLf & vbCrLf & _
             "Restart this PC once, then double-click this launcher again.", _
             vbExclamation, "EAC POS"
      WScript.Quit 1
    End If
  End If
End If

If GetPing() = "" Then
  Log "starting hidden server"
  On Error Resume Next
  sh.CurrentDirectory = base
  ' 0 = hidden window: no black console window ever appears.
  sh.Run """" & psExe & """ -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & serverPs1 & """", 0, False
  If Err.Number <> 0 Then
    Log "ERROR: sh.Run failed " & Err.Number & " " & Err.Description
    MsgBox "The local server could not be started." & vbCrLf & vbCrLf & _
           "Please run ""EAC Launcher (backup).cmd"" instead.", _
           vbCritical, "EAC POS"
    WScript.Quit 1
  End If
  Err.Clear
  On Error GoTo 0
End If

' Wait until the local server answers (max ~20 seconds on a slow PC).
up = False
For i = 1 To 80
  If GetPing() <> "" Then
    up = True
    Log "server ready after " & (i * 250) & " ms"
    Exit For
  End If
  WScript.Sleep 250
Next

If Not up Then
  Log "ERROR: server did not answer"
  MsgBox "The local server did not start, so the program cannot open." & vbCrLf & vbCrLf & _
         "1. Close this message." & vbCrLf & _
         "2. Double-click ""EAC Launcher (backup).cmd""." & vbCrLf & _
         "3. If Windows asks for permission, choose Allow / Yes." & vbCrLf & vbCrLf & _
         "If it still fails, double-click ""Check Compatibility.cmd""." & vbCrLf & vbCrLf & _
         "Technical details:" & vbCrLf & _
         "Launcher log: " & logFile & ServerErrorText(), _
         vbCritical, "EAC POS"
  WScript.Quit 1
End If

' Open a modern browser directly. Opening the Windows "default browser" is
' not reliable: on some PCs it is still Internet Explorer, which cannot run
' this program, while the same HTML file works fine in Edge or Chrome.
browser = FindBrowser()
If browser <> "" Then
  Log "opening browser: " & browser
  On Error Resume Next
  sh.Run """" & browser & """ """ & url & """", 1, False
  If Err.Number <> 0 Then
    Err.Clear
    Log "browser launch failed; opening default browser"
    sh.Run url, 1, False
  End If
  Err.Clear
  On Error GoTo 0
Else
  Log "no Edge/Chrome found; opening default browser"
  sh.Run url, 1, False
End If

WScript.Quit 0

' ----------------------------------------------------------------------------
Function GetPing()
  Dim http, st, body
  GetPing = ""
  st = 0
  body = ""
  On Error Resume Next

  ' WinHTTP first: it talks to the local server directly, never through a proxy.
  Set http = CreateObject("WinHttp.WinHttpRequest.5.1")
  If Err.Number <> 0 Then
    Err.Clear
    Set http = CreateObject("MSXML2.XMLHTTP.6.0")
    If Err.Number <> 0 Then
      Err.Clear
      Set http = CreateObject("MSXML2.XMLHTTP")
    End If
  End If

  If Err.Number <> 0 Then
    Err.Clear
    On Error GoTo 0
    Exit Function
  End If
  Err.Clear

  http.SetProxy 1
  Err.Clear
  http.setTimeouts 700, 700, 700, 1200
  Err.Clear
  http.Open "GET", url & "api/ping", False
  Err.Clear
  http.Send
  If Err.Number = 0 Then
    st = http.Status
    If st = 200 Then body = http.ResponseText
  End If
  Err.Clear
  On Error GoTo 0

  If st = 200 Then GetPing = body
End Function

Function StopServer()
  Dim http, st
  StopServer = False
  On Error Resume Next
  Set http = CreateObject("WinHttp.WinHttpRequest.5.1")
  If Err.Number <> 0 Then
    Err.Clear
    On Error GoTo 0
    Exit Function
  End If
  http.SetProxy 1
  Err.Clear
  http.setTimeouts 700, 700, 700, 1200
  http.Open "POST", url & "api/quit", False
  http.Send "{}"
  If Err.Number = 0 Then
    st = http.Status
    If st = 200 Then StopServer = True
  End If
  Err.Clear
  On Error GoTo 0
End Function

Function GetPsMajor()
  Dim v, keys, i, n
  GetPsMajor = 0
  On Error Resume Next
  keys = Array( _
    "HKLM\SOFTWARE\Microsoft\PowerShell\3\PowerShellEngine\PowerShellVersion", _
    "HKLM\SOFTWARE\WOW6432Node\Microsoft\PowerShell\3\PowerShellEngine\PowerShellVersion", _
    "HKLM\SOFTWARE\Microsoft\PowerShell\1\PowerShellEngine\PowerShellVersion", _
    "HKLM\SOFTWARE\WOW6432Node\Microsoft\PowerShell\1\PowerShellEngine\PowerShellVersion" )
  For i = 0 To UBound(keys)
    v = ""
    v = sh.RegRead(keys(i))
    If Err.Number = 0 And Len(v) > 0 Then
      n = 0
      On Error Resume Next
      n = CInt(Split(v, ".")(0))
      If Err.Number = 0 And n > GetPsMajor Then GetPsMajor = n
      Err.Clear
    End If
    Err.Clear
  Next
  On Error GoTo 0
End Function

Function FindBrowser()
  Dim cands, i, p, regs, r
  FindBrowser = ""

  cands = Array( _
    sh.ExpandEnvironmentStrings("%ProgramFiles%") & "\Microsoft\Edge\Application\msedge.exe", _
    sh.ExpandEnvironmentStrings("%ProgramFiles(x86)%") & "\Microsoft\Edge\Application\msedge.exe", _
    sh.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Microsoft\Edge\Application\msedge.exe", _
    sh.ExpandEnvironmentStrings("%ProgramFiles%") & "\Google\Chrome\Application\chrome.exe", _
    sh.ExpandEnvironmentStrings("%ProgramFiles(x86)%") & "\Google\Chrome\Application\chrome.exe", _
    sh.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Google\Chrome\Application\chrome.exe" )

  For i = 0 To UBound(cands)
    p = cands(i)
    If InStr(p, "%") = 0 Then
      If fso.FileExists(p) Then
        FindBrowser = p
        Exit Function
      End If
    End If
  Next

  ' Custom install locations are registered here.
  regs = Array( _
    "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe\", _
    "HKLM\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe\", _
    "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe\", _
    "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe\", _
    "HKLM\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe\", _
    "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe\" )

  For i = 0 To UBound(regs)
    r = RegPath(regs(i))
    If r <> "" Then
      FindBrowser = r
      Exit Function
    End If
  Next
End Function

Function RegPath(key)
  Dim v
  RegPath = ""
  On Error Resume Next
  v = sh.RegRead(key)
  If Err.Number = 0 Then
    v = Replace(v, """", "")
    If fso.FileExists(v) Then RegPath = v
  End If
  Err.Clear
  On Error GoTo 0
End Function

Function JsonString(text, key)
  Dim needle, p, q, c, v
  JsonString = ""
  If text = "" Then Exit Function
  needle = """" & key & """:"
  p = InStr(1, text, needle, vbTextCompare)
  If p = 0 Then Exit Function
  p = p + Len(needle)

  ' Skip spaces after the colon.
  Do While p <= Len(text) And Mid(text, p, 1) = " "
    p = p + 1
  Loop
  If p > Len(text) Then Exit Function

  c = Mid(text, p, 1)
  If c = """" Then
    ' Text value: read up to the closing quote.
    p = p + 1
    q = InStr(p, text, """", vbTextCompare)
    If q = 0 Then Exit Function
    v = Mid(text, p, q - p)
    v = Replace(v, "\\", "\")
  Else
    ' Number or true/false: read up to the next comma or brace.
    q = p
    Do While q <= Len(text)
      c = Mid(text, q, 1)
      If c = "," Or c = "}" Then Exit Do
      q = q + 1
    Loop
    v = Trim(Mid(text, p, q - p))
  End If

  JsonString = v
End Function

Function NormPath(p)
  Dim s
  s = Trim(p)
  s = Replace(s, "/", "\")
  Do While Len(s) > 3 And Right(s, 1) = "\"
    s = Left(s, Len(s) - 1)
  Loop
  NormPath = LCase(s)
End Function

Function ServerErrorText()
  Dim errFile, f, txt, lines, i, start
  ServerErrorText = ""
  On Error Resume Next
  errFile = fso.BuildPath(sh.ExpandEnvironmentStrings("%TEMP%"), "EAC-server.log")
  If Not fso.FileExists(errFile) Then
    Err.Clear
    On Error GoTo 0
    Exit Function
  End If
  Set f = fso.OpenTextFile(errFile, 1, False)
  txt = f.ReadAll
  f.Close
  If Len(txt) = 0 Then
    Err.Clear
    On Error GoTo 0
    Exit Function
  End If
  lines = Split(txt, vbCrLf)
  start = UBound(lines) - 2
  If start < 0 Then start = 0
  ServerErrorText = vbCrLf & "Server log: " & errFile
  For i = start To UBound(lines)
    If Trim(lines(i)) <> "" Then ServerErrorText = ServerErrorText & vbCrLf & "  " & lines(i)
  Next
  Err.Clear
  On Error GoTo 0
End Function

Sub Log(msg)
  On Error Resume Next
  Dim f
  Set f = fso.OpenTextFile(logFile, 8, True)
  f.WriteLine Now & "  " & msg
  f.Close
  Err.Clear
End Sub
#LAUNCHER-END

#PSSTART
$ErrorActionPreference = 'Continue'
$base = (Get-Location).Path
$self = Join-Path $base 'EAC Repair.cmd'
$launcher = Join-Path $base 'EAC Launcher.vbs'
$html = Join-Path $base 'EAC POS v2.3.html'
$server = Join-Path $base 'EAC Server.ps1'
$relay = Join-Path $base 'EAC Telegram Relay.ps1'
$backup = Join-Path $base 'EAC Launcher (backup).cmd'
$readme = Join-Path $base 'Read Me.txt'

function Say([string]$en, [string]$ar) {
  Write-Host ('  ' + $en)
}

function Show-Result([string]$en, [string]$ar, [int]$icon) {
  try {
    $wsh = New-Object -ComObject WScript.Shell
    [void]$wsh.Popup(($en + "`r`n`r`n" + $ar), 0, 'EAC Repair / إصلاح', $icon)
  } catch { }
}

Write-Host ''
Write-Host '  EAC - Repair'
Write-Host '  -------------------'
Write-Host ''

$repaired = $false
$failed = $false
$embedded = ''

function Normalize-Vbs([string]$text) {
  $x = $text -replace "`r`n", "`n"
  $x = $x -replace "`n", "`r`n"
  $x = $x.TrimStart([char[]]"`r`n")
  $x = $x.TrimEnd([char[]]"`r`n")
  return $x + "`r`n"
}

# --- extract the clean launcher that is embedded in this file ---
try {
  $all = [System.IO.File]::ReadAllText($self)
  $beginMark = '#LAUNCHER-BEGIN'
  $endMark = '#LAUNCHER-END'
  $b = $all.IndexOf($beginMark)
  $e = $all.IndexOf($endMark)
  if ($b -ge 0 -and $e -gt $b) {
    $embedded = Normalize-Vbs $all.Substring($b + $beginMark.Length, $e - ($b + $beginMark.Length))
  }
} catch { }

if ($embedded.Length -lt 1000 -or -not $embedded.Contains('Option Explicit')) {
  Say 'ERROR: this repair file is damaged. Extract the original ZIP again.' 'خطأ: ملف الإصلاح تالف. أعد استخراج ملف ZIP الأصلي.'
  $failed = $true
} else {
  # --- write the launcher cleanly (no BOM, no UTF-16) ---
  try {
    if (Test-Path -LiteralPath $launcher) {
      $it = Get-Item -LiteralPath $launcher -Force
      if (($it.Attributes -band [System.IO.FileAttributes]::ReadOnly) -ne 0) { $it.Attributes = $it.Attributes -bxor [System.IO.FileAttributes]::ReadOnly }
      if (($it.Attributes -band [System.IO.FileAttributes]::Hidden) -ne 0) { $it.Attributes = $it.Attributes -bxor [System.IO.FileAttributes]::Hidden }
      $bytes = [System.IO.File]::ReadAllBytes($launcher)
      $bom = ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF)
      $u16 = ($bytes.Length -ge 2 -and (($bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE) -or ($bytes[0] -eq 0xFE -and $bytes[1] -eq 0xFF)))
      $cur = Normalize-Vbs ([System.IO.File]::ReadAllText($launcher))
      if ($bom -or $u16 -or ($cur -ne $embedded)) {
        [System.IO.File]::WriteAllText($launcher, $embedded, (New-Object System.Text.UTF8Encoding($false)))
        Say 'The launcher file was damaged and has been repaired.' 'ملف التشغيل كان تالفاً وتم إصلاحه.'
        $repaired = $true
      } else {
        Say 'The launcher file is already correct.' 'ملف التشغيل سليم بالفعل.'
      }
    } else {
      [System.IO.File]::WriteAllText($launcher, $embedded, (New-Object System.Text.UTF8Encoding($false)))
      Say 'The launcher file was missing and has been restored.' 'ملف التشغيل كان مفقوداً وتمت استعادته.'
      $repaired = $true
    }
  } catch {
    Say ('ERROR: could not write the launcher: ' + $_.Exception.Message) 'خطأ: لم نتمكن من كتابة ملف التشغيل.'
    $failed = $true
  }
}

# --- check the other required files ---
$htmlOk = $false
try { $htmlOk = (Test-Path -LiteralPath $html) -and ((Get-Item -LiteralPath $html).Length -ge 500000) } catch { }
$serverOk = Test-Path -LiteralPath $server
$relayOk = Test-Path -LiteralPath $relay
$backupOk = Test-Path -LiteralPath $backup
$readmeOk = Test-Path -LiteralPath $readme
Write-Host ''
if ($htmlOk -and $serverOk -and $relayOk -and $backupOk -and $readmeOk) {
  Say 'All program files are present.' 'كل ملفات البرنامج موجودة.'
} else {
  Say 'Some program files are missing. Extract the ZIP again.' 'بعض ملفات البرنامج مفقودة. أعد استخراج ملف ZIP.'
  if (-not $htmlOk) { Write-Host '    - EAC POS v2.3.html' }
  if (-not $serverOk) { Write-Host '    - EAC Server.ps1' }
  if (-not $relayOk) { Write-Host '    - EAC Telegram Relay.ps1' }
  if (-not $backupOk) { Write-Host '    - EAC Launcher (backup).cmd' }
  if (-not $readmeOk) { Write-Host '    - Read Me.txt' }
}

Write-Host ''
if ($failed) {
  Say 'Repair did not finish. Use "EAC Launcher (backup).cmd".' 'لم يكتمل الإصلاح. استخدم "EAC Launcher (backup).cmd".'
  Show-Result 'The repair tool could not fix the launcher. Start the program with "EAC Launcher (backup).cmd" instead.' 'لم تكتمل عملية الإصلاح. شغّل البرنامج من "EAC Launcher (backup).cmd" بدلاً من ذلك.' 16
} elseif ($repaired) {
  Say 'Done. Now double-click: EAC Launcher.cmd' 'تم. الآن انقر مرتين على: EAC Launcher.cmd'
  Show-Result 'The launcher was repaired successfully. Click OK, then double-click EAC Launcher.cmd to start the program.' 'تم إصلاح ملف التشغيل بنجاح. اضغط OK ثم انقر مرتين على EAC Launcher.cmd لتشغيل البرنامج. بياناتك وتفعيلك لم يتغيرا.' 64
} else {
  Say 'Nothing to repair. Start with EAC Launcher.cmd' 'لا يوجد ما يحتاج إصلاحاً. ابدأ بـ EAC Launcher.cmd'
  Show-Result 'Nothing needed repair. Double-click EAC Launcher.cmd to start the program.' 'لا يوجد ما يحتاج إصلاحاً. انقر مرتين على EAC Launcher.cmd لتشغيل البرنامج.' 64
}
Write-Host ''
