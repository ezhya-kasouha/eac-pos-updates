@echo off
setlocal
cd /d "%~dp0"
rem ==========================================================================
rem  EAC POS - Compatibility Check
rem  Double-click this file. It only reads information; it changes nothing.
rem  It opens a readable Arabic/English report in your browser.
rem ==========================================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$p='%~f0'; $s=[IO.File]::ReadAllText($p); iex ($s.Substring($s.LastIndexOf('#PSSTART')))"
if errorlevel 1 (
  echo.
  echo The compatibility check could not run.
  echo PowerShell may be blocked on this computer.
  echo Try starting the program with "EAC Launcher ^(backup^).cmd".
  echo.
  pause
)
exit /b

#PSSTART
$ErrorActionPreference = 'SilentlyContinue'
$rows = New-Object System.Collections.ArrayList

function Add-Row([string]$itemEn, [string]$itemAr, [string]$needEn, [string]$needAr, [string]$found, [string]$state) {
  [void]$rows.Add([pscustomobject]@{
    ItemEn = $itemEn; ItemAr = $itemAr; NeedEn = $needEn; NeedAr = $needAr; Found = $found; State = $state
  })
}

function Get-FileVersion([string]$path) {
  try {
    if (Test-Path -LiteralPath $path) { return (Get-Item -LiteralPath $path).VersionInfo.ProductVersion }
  } catch { }
  return ''
}

# ---------- Windows ----------
$os = Get-CimInstance Win32_OperatingSystem
$build = [int](Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion').CurrentBuildNumber
$winName = 'Windows'
if ($build -ge 22000) { $winName = 'Windows 11' }
elseif ($build -ge 10240) { $winName = 'Windows 10' }
elseif ($build -eq 9600) { $winName = 'Windows 8.1' }
elseif ($build -eq 9200) { $winName = 'Windows 8' }
elseif ($build -eq 7601) { $winName = 'Windows 7 SP1' }
elseif ($build -eq 7600) { $winName = 'Windows 7' }
$osFound = "$winName ($($os.OSArchitecture)) - build $build"
if ($build -ge 10240) { Add-Row 'Windows' 'نظام ويندوز' 'Windows 10 or 11' 'ويندوز 10 أو 11' $osFound 'ok' }
elseif ($build -ge 9600) { Add-Row 'Windows' 'نظام ويندوز' 'Windows 10 or 11' 'ويندوز 10 أو 11' $osFound 'warn' }
else { Add-Row 'Windows' 'نظام ويندوز' 'Windows 10 or 11' 'ويندوز 10 أو 11' $osFound 'fail' }

# ---------- PowerShell ----------
$psv = $PSVersionTable.PSVersion
$psFound = "$psv (Desktop edition: $($PSVersionTable.PSEdition))"
if ($psv.Major -ge 5 -and $psv.Minor -ge 1) { Add-Row 'PowerShell' 'PowerShell' '5.1 or newer' '5.1 أو أحدث' $psFound 'ok' }
elseif ($psv.Major -ge 3) { Add-Row 'PowerShell' 'PowerShell' '5.1 or newer' '5.1 أو أحدث' $psFound 'warn' }
else { Add-Row 'PowerShell' 'PowerShell' '5.1 or newer' '5.1 أو أحدث' $psFound 'fail' }

# ---------- .NET Framework ----------
$rel = 0
try { $rel = [int](Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -Name Release).Release } catch { }
$netName = ''
if ($rel -ge 533320) { $netName = '4.8.1 or newer' }
elseif ($rel -ge 528040) { $netName = '4.8' }
elseif ($rel -ge 461808) { $netName = '4.7.2' }
elseif ($rel -ge 460798) { $netName = '4.7' }
elseif ($rel -ge 394802) { $netName = '4.6.2' }
elseif ($rel -ge 393295) { $netName = '4.6' }
elseif ($rel -ge 379893) { $netName = '4.5.2' }
elseif ($rel -ge 378675) { $netName = '4.5.1' }
elseif ($rel -ge 378389) { $netName = '4.5' }
$netFound = if ($netName) { "$netName (release $rel)" } else { "not found (release $rel)" }
if ($rel -ge 378389) { Add-Row '.NET Framework' '.NET Framework' '4.5 or newer' '4.5 أو أحدث' $netFound 'ok' }
else { Add-Row '.NET Framework' '.NET Framework' '4.5 or newer' '4.5 أو أحدث' $netFound 'fail' }

# ---------- Windows Script Host ----------
$wsh = Test-Path -LiteralPath "$env:WINDIR\System32\cscript.exe"
$wshFound = if ($wsh) { 'cscript.exe present' } else { 'cscript.exe missing' }
if ($wsh) { Add-Row 'Windows Script Host' 'Windows Script Host' 'Installed (built in)' 'مثبّت (مدمج)' $wshFound 'ok' }
else { Add-Row 'Windows Script Host' 'Windows Script Host' 'Installed (built in)' 'مثبّت (مدمج)' $wshFound 'fail' }

# ---------- Browser ----------
$edgePaths = @(
  "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
  "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"
)
$chromePaths = @(
  "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
  "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
  "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
)
$bestName = ''
$bestVersion = ''
foreach ($p in $edgePaths) {
  $v = Get-FileVersion $p
  if ($v) { $bestName = 'Microsoft Edge'; $bestVersion = $v; break }
}
if (-not $bestVersion) {
  foreach ($p in $chromePaths) {
    $v = Get-FileVersion $p
    if ($v) { $bestName = 'Google Chrome'; $bestVersion = $v; break }
  }
}
$browserFound = if ($bestVersion) { "$bestName $bestVersion" } else { 'No Edge or Chrome found' }
$browserMajor = 0
if ($bestVersion) { $browserMajor = [int](($bestVersion -split '\.')[0]) }
if ($browserMajor -ge 105) { Add-Row 'Browser' 'المتصفح' 'Edge/Chrome 105 or newer' 'Edge/Chrome 105 أو أحدث' $browserFound 'ok' }
elseif ($browserMajor -ge 80) { Add-Row 'Browser' 'المتصفح' 'Edge/Chrome 105 or newer' 'Edge/Chrome 105 أو أحدث' $browserFound 'warn' }
else { Add-Row 'Browser' 'المتصفح' 'Edge/Chrome 105 or newer' 'Edge/Chrome 105 أو أحدث' $browserFound 'fail' }

# ---------- Program files ----------
$base = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $base) { $base = (Get-Location).Path }
$htmlPath = Join-Path $base 'EAC POS v2.2.html'
$serverPath = Join-Path $base 'EAC Server.ps1'
$relayPath = Join-Path $base 'EAC Telegram Relay.ps1'
$launcherCmdPath = Join-Path $base 'EAC Launcher.cmd'
$launcherVbsPath = Join-Path $base 'EAC Launcher.vbs'
$launcherDataPath = Join-Path $base 'EAC Launcher.vbs.dat'
$backupPath = Join-Path $base 'EAC Launcher (backup).cmd'
$repairPath = Join-Path $base 'EAC Repair.cmd'
$readmePath = Join-Path $base 'Read Me.txt'
# The silent launcher is shipped as .vbs.dat; the .vbs is created on first
# start by EAC Launcher.cmd. Check whichever file exists.
$launcherPath = $launcherDataPath
if (Test-Path -LiteralPath $launcherVbsPath) { $launcherPath = $launcherVbsPath }
$htmlSize = 0
if (Test-Path -LiteralPath $htmlPath) { $htmlSize = (Get-Item -LiteralPath $htmlPath).Length }
$filesOk = (Test-Path -LiteralPath $serverPath) -and (Test-Path -LiteralPath $relayPath) -and (Test-Path -LiteralPath $launcherCmdPath) -and (Test-Path -LiteralPath $launcherPath) -and (Test-Path -LiteralPath $backupPath) -and (Test-Path -LiteralPath $repairPath) -and (Test-Path -LiteralPath $readmePath) -and ($htmlSize -ge 500000)
$filesFound = "HTML: $([math]::Round($htmlSize/1MB,2)) MB; Server: $(Test-Path -LiteralPath $serverPath); Relay: $(Test-Path -LiteralPath $relayPath); Launcher: $(Test-Path -LiteralPath $launcherCmdPath); Silent launcher: $(Test-Path -LiteralPath $launcherPath); Backup: $(Test-Path -LiteralPath $backupPath); Repair: $(Test-Path -LiteralPath $repairPath); Read Me: $(Test-Path -LiteralPath $readmePath)"
if ($filesOk) { Add-Row 'Program files' 'ملفات البرنامج' 'All required files together' 'كل الملفات المطلوبة معاً' $filesFound 'ok' }
else { Add-Row 'Program files' 'ملفات البرنامج' 'All required files together' 'كل الملفات المطلوبة معاً' $filesFound 'fail' }

# ---------- Launcher integrity ----------
$launcherState = 'ok'
$launcherFound = 'Launcher file is intact'
if (Test-Path -LiteralPath $launcherPath) {
  try {
    $lb = [System.IO.File]::ReadAllBytes($launcherPath)
    $isBom = ($lb.Length -ge 3 -and $lb[0] -eq 0xEF -and $lb[1] -eq 0xBB -and $lb[2] -eq 0xBF)
    $isU16 = ($lb.Length -ge 2 -and (($lb[0] -eq 0xFF -and $lb[1] -eq 0xFE) -or ($lb[0] -eq 0xFE -and $lb[1] -eq 0xFF)))
    $hasNul = $false
    $limit = [Math]::Min($lb.Length, 400)
    for ($li = 0; $li -lt $limit; $li++) { if ($lb[$li] -eq 0) { $hasNul = $true; break } }
    if ($isBom -or $isU16 -or $hasNul) {
      $launcherState = 'fail'
      $launcherFound = 'Damaged launcher (byte-order mark). Double-click EAC Repair.cmd'
    }
  } catch {
    $launcherState = 'fail'
    $launcherFound = 'Could not read the launcher file'
  }
} else {
  $launcherState = 'fail'
  $launcherFound = 'Launcher file is missing. Extract the ZIP again'
}
Add-Row 'Launcher file' 'ملف التشغيل' 'Not damaged (no BOM)' 'غير تالف (بدون BOM)' $launcherFound $launcherState

# ---------- Port 17893 ----------
$portState = 'ok'
$portFound = 'Port 17893 is free'
try {
  $ping = Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:17893/api/ping' -TimeoutSec 2
  $info = $null
  try { $info = $ping.Content | ConvertFrom-Json } catch { }
  if ($ping.Content -match 'EAC') {
    $wantApp = Join-Path $base 'EAC POS v2.2.html'
    if ($info -and $info.appPath -and ($info.appPath -ne $wantApp)) {
      $portState = 'warn'
      $portFound = "Another copy is running from: $($info.appPath)"
    } elseif ($info -and $info.build -and ([string]$info.build -ne '4')) {
      $portState = 'warn'
      $portFound = 'An older EAC server is running; start the launcher to update it'
    } else {
      $portFound = 'EAC server is already running on 17893 (this copy)'
    }
  }
  else { $portState = 'warn'; $portFound = 'Port 17893 is used by another program' }
} catch {
  $client = New-Object System.Net.Sockets.TcpClient
  try {
    $iar = $client.BeginConnect('127.0.0.1', 17893, $null, $null)
    if ($iar.AsyncWaitHandle.WaitOne(700)) {
      $client.EndConnect($iar)
      $portState = 'warn'
      $portFound = 'Port 17893 is used by another program (not EAC)'
    }
  } catch { }
  finally { $client.Close() }
}
Add-Row 'Port 17893' 'المنفذ 17893' 'Free, or used by EAC' 'حر أو مستخدم بواسطة EAC' $portFound $portState

# ---------- Optional: camera ----------
$camFound = 'No camera detected'
$camState = 'warn'
try {
  $cams = Get-PnpDevice -Class Camera -Status OK -ErrorAction Stop
  if ($cams) { $camFound = "$(@($cams).Count) camera(s) detected"; $camState = 'ok' }
} catch { }
Add-Row 'Camera (optional)' 'الكاميرا (اختياري)' 'Only for QR scanning' 'لقارئ QR فقط' $camFound $camState

# ---------- Optional: printer ----------
$prnFound = 'No printer detected'
$prnState = 'warn'
try {
  $prns = Get-Printer -ErrorAction Stop
  if ($prns) { $prnFound = "$($prns.Count) printer(s) detected"; $prnState = 'ok' }
} catch { }
Add-Row 'Printer (optional)' 'الطابعة (اختياري)' 'Only for printing' 'للطباعة فقط' $prnFound $prnState

# ---------- verdict ----------
$required = $rows | Where-Object { $_.ItemEn -notmatch 'optional' }
$fails = @($required | Where-Object { $_.State -eq 'fail' }).Count
$warns = @($required | Where-Object { $_.State -eq 'warn' }).Count
$verdictEn = 'This PC is compatible. Start the program with EAC Launcher.cmd.'
$verdictAr = 'هذا الجهاز متوافق. شغّل البرنامج من EAC Launcher.cmd.'
$verdictClass = 'ok'
if ($fails -gt 0) {
  $verdictEn = 'This PC is NOT compatible yet. See the red rows below.'
  $verdictAr = 'هذا الجهاز غير متوافق حالياً. راجع البنود الحمراء أدناه.'
  $verdictClass = 'fail'
} elseif ($warns -gt 0) {
  $verdictEn = 'This PC should work, with warnings. See the yellow rows below.'
  $verdictAr = 'من المفترض أن يعمل الجهاز مع بعض الملاحظات. راجع البنود الصفراء أدناه.'
  $verdictClass = 'warn'
}

$badge = @{
  ok   = '<span class="b ok">OK</span>'
  warn = '<span class="b warn">WARN</span>'
  fail = '<span class="b fail">FAIL</span>'
}
$rowHtml = ''
foreach ($r in $rows) {
  $rowHtml += "<tr><td class=`"item`"><div class=`"en`">$($r.ItemEn)</div><div class=`"ar`">$($r.ItemAr)</div></td>" +
              "<td><div class=`"en`">$($r.NeedEn)</div><div class=`"ar`">$($r.NeedAr)</div></td>" +
              "<td class=`"found`">$([System.Net.WebUtility]::HtmlEncode($r.Found))</td>" +
              "<td class=`"st`">$($badge[$r.State])</td></tr>"
}

$now = Get-Date -Format 'yyyy-MM-dd HH:mm'
$pc = $env:COMPUTERNAME
$html = @"
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>EAC POS - فحص التوافق / Compatibility Check</title>
<style>
  body { margin:0; padding:24px; background:#0f172a; color:#e2e8f0; font-family:'Segoe UI',Tahoma,Arial,sans-serif; }
  .wrap { max-width:980px; margin:0 auto; }
  h1 { font-size:24px; margin:0 0 6px; color:#fff; }
  .sub { color:#94a3b8; font-size:13px; margin-bottom:20px; }
  .verdict { border-radius:16px; padding:18px 20px; margin-bottom:18px; border:1px solid; }
  .verdict.ok { background:#052e1b; border-color:#166534; }
  .verdict.warn { background:#3b2a05; border-color:#a16207; }
  .verdict.fail { background:#3b0a0a; border-color:#b91c1c; }
  .verdict .en { font-size:17px; font-weight:800; color:#fff; }
  .verdict .ar { font-size:16px; font-weight:700; margin-top:6px; }
  table { width:100%; border-collapse:collapse; background:#111c33; border-radius:14px; overflow:hidden; }
  th, td { padding:12px 14px; border-bottom:1px solid #1e2d4d; text-align:start; vertical-align:top; }
  th { background:#16233d; color:#93c5fd; font-size:12px; text-transform:uppercase; letter-spacing:.4px; }
  td { font-size:13px; }
  .item .en, td .en { font-weight:700; color:#fff; }
  .item .ar, td .ar { color:#94a3b8; font-size:12px; margin-top:2px; }
  .found { font-family:Consolas,monospace; font-size:12px; color:#cbd5e1; word-break:break-word; }
  .st { text-align:center; white-space:nowrap; }
  .b { display:inline-block; padding:3px 10px; border-radius:999px; font-size:11px; font-weight:800; }
  .b.ok { background:#052e1b; color:#4ade80; border:1px solid #166534; }
  .b.warn { background:#3b2a05; color:#facc15; border:1px solid #a16207; }
  .b.fail { background:#3b0a0a; color:#f87171; border:1px solid #b91c1c; }
  .note { margin-top:18px; padding:14px 16px; border-radius:12px; background:#111c33; border:1px solid #1e2d4d; font-size:12px; line-height:1.9; color:#cbd5e1; }
  .note b { color:#fff; }
  .foot { margin-top:14px; color:#64748b; font-size:11px; text-align:center; }
  @media print { body { background:#fff; color:#0f172a; } table { background:#fff; } th { background:#f1f5f9; color:#0f172a; } td { border-color:#e2e8f0; } .verdict .en, .verdict .ar, .item .en, td .en { color:#0f172a; } .note { background:#f8fafc; border-color:#e2e8f0; color:#334155; } }
</style>
</head>
<body>
<div class="wrap">
  <h1>EAC POS - فحص التوافق</h1>
  <div class="sub">Compatibility Check &nbsp;|&nbsp; $now &nbsp;|&nbsp; $pc</div>

  <div class="verdict $verdictClass">
    <div class="en">$verdictEn</div>
    <div class="ar">$verdictAr</div>
  </div>

  <table>
    <thead><tr><th>Item / البند</th><th>Required / المطلوب</th><th>Found on this PC / الموجود</th><th>Status</th></tr></thead>
    <tbody>$rowHtml</tbody>
  </table>

  <div class="note">
    <b>ملاحظات مهمة / Important:</b><br>
    • هذا الفحص لا يغيّر أي شيء على الجهاز. / This check changes nothing on the PC.<br>
    • البرنامج لا يحتاج إنترنت ولا أي مكتبات خارجية. / No internet and no external libraries are needed.<br>
    • كل جهاز جديد يحتاج كود تفعيل جديداً. / A new PC needs a new activation code.<br>
    • إذا ظهر خطأ Windows Script Host عند السطر 1 فملف التشغيل تالف: شغّل EAC Repair.cmd. / If Windows Script Host shows an error at Line 1, the launcher is damaged: run EAC Repair.cmd.<br>
    • إذا كان البند أصفر (WARN) فعادةً يعمل البرنامج، لكن يُفضّل تحديث المتصفح أو ويندوز.<br>
    • If a row is yellow (WARN) the program usually works, but updating the browser or Windows is recommended.
  </div>
  <div class="foot">EAC POS v2 - local compatibility report</div>
</div>
</body>
</html>
"@

$report = Join-Path $env:TEMP 'EAC Compatibility Report.html'
[System.IO.File]::WriteAllText($report, $html, (New-Object System.Text.UTF8Encoding($true)))

Write-Host ''
Write-Host 'EAC compatibility check'
Write-Host '-------------------------------'
foreach ($r in $rows) { Write-Host ("[{0}] {1}: {2}" -f $r.State.ToUpper(), $r.ItemEn, $r.Found) }
Write-Host ''
Write-Host $verdictEn
Write-Host 'The Arabic result is shown in the report that opens in your browser.'
Write-Host ''
Write-Host "Report: $report"
Start-Process $report
