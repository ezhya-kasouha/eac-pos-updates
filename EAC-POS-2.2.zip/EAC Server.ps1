# ============================================================================
#  EAC local server
#  Serves the POS HTML and stores the database in a hidden AppData file.
#  Listens only on 127.0.0.1:17893 (this PC only, no internet).
# ============================================================================

$ErrorActionPreference = 'Stop'
$Port = 17893
$ServerBuild = 8

# Find this script's folder. $PSScriptRoot exists in PowerShell 3 and newer;
# the fallbacks keep the server working on older PowerShell versions.
$ScriptDir = $PSScriptRoot
if (-not $ScriptDir) {
  try { $ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path } catch { }
}
if (-not $ScriptDir) { $ScriptDir = (Get-Location).Path }

$LogFile = Join-Path $env:TEMP 'EAC-server.log'
function Write-ServerLog([string]$message) {
  try {
    $line = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') + '  ' + $message
    Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8
  } catch { }
}

trap {
  Write-ServerLog ('FATAL: ' + $_.Exception.Message + ' | ' + $_.InvocationInfo.PositionMessage)
  exit 1
}

if (-not (Get-Command ConvertTo-Json -ErrorAction SilentlyContinue)) {
  Write-ServerLog ('FATAL: PowerShell ' + $PSVersionTable.PSVersion.ToString() + ' is too old (ConvertTo-Json missing). PowerShell 3.0 or newer is required.')
  exit 2
}

$AppPath = Join-Path $ScriptDir 'EAC POS v2.2.html'
if (-not (Test-Path -LiteralPath $AppPath)) {
  $altApp = Join-Path $env:USERPROFILE 'Desktop\EAC POS v2.2.html'
  if (Test-Path -LiteralPath $altApp) {
    $AppPath = $altApp
    $ScriptDir = Split-Path -Parent $altApp
  }
}
$DataDir = Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\Caches'
$DataFile = Join-Path $DataDir '{9C7E2A14-5B3D-4F60-8A21-D4E6F8B0C3A7}.dat'
$LicFile  = Join-Path $DataDir '{9C7E2A14-5B3D-4F60-8A21-D4E6F8B0C3A7}.lic'
$UsersFile = Join-Path $DataDir '{9C7E2A14-5B3D-4F60-8A21-D4E6F8B0C3A7}.usr'
$DeviceFile = Join-Path $DataDir '{9C7E2A14-5B3D-4F60-8A21-D4E6F8B0C3A7}.dev'
$ChatFile   = Join-Path $DataDir '{9C7E2A14-5B3D-4F60-8A21-D4E6F8B0C3A7}.tlg'

# Stable machine identity for the activation lock. The Windows MachineGuid
# does not change when the PC is restarted, so the device code stays the
# same and the activation is never lost after a reboot.
$MachineId = ''
try {
  $machineGuid = (Get-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Cryptography' -Name MachineGuid -ErrorAction Stop).MachineGuid
  if ($machineGuid) {
    $sha256 = [System.Security.Cryptography.SHA256]::Create()
    $hashBytes = $sha256.ComputeHash([System.Text.Encoding]::UTF8.GetBytes([string]$machineGuid))
    $MachineId = [System.BitConverter]::ToString($hashBytes).Replace('-', '').ToLowerInvariant()
    $sha256.Dispose()
  }
} catch { $MachineId = '' }

if (-not (Test-Path -LiteralPath $DataDir)) {
  New-Item -ItemType Directory -Path $DataDir -Force | Out-Null
}

Write-ServerLog ('start; ps=' + $PSVersionTable.PSVersion.ToString() + '; dir=' + $ScriptDir + '; app=' + $AppPath + '; appExists=' + (Test-Path -LiteralPath $AppPath) + '; data=' + $DataFile)

function Hide-File([string]$Path) {
  try {
    if (Test-Path -LiteralPath $Path) {
      $item = Get-Item -LiteralPath $Path -Force
      $item.Attributes = $item.Attributes -bor [System.IO.FileAttributes]::Hidden
    }
  } catch { }
}

function Show-FileForWrite([string]$Path) {
  try {
    if (Test-Path -LiteralPath $Path) {
      $item = Get-Item -LiteralPath $Path -Force
      if ($item.Attributes -band [System.IO.FileAttributes]::Hidden) {
        $item.Attributes = $item.Attributes -bxor [System.IO.FileAttributes]::Hidden
      }
    }
  } catch { }
}

function Send-Bytes($stream, [int]$status, [string]$contentType, [byte[]]$bytes) {
  $reason = switch ($status) {
    200 { 'OK' }
    204 { 'No Content' }
    400 { 'Bad Request' }
    404 { 'Not Found' }
    405 { 'Method Not Allowed' }
    500 { 'Internal Server Error' }
    default { 'OK' }
  }
  $header = "HTTP/1.1 $status $reason`r`n" +
            "Content-Type: $contentType`r`n" +
            "Content-Length: $($bytes.Length)`r`n" +
            "Access-Control-Allow-Origin: *`r`n" +
            "Access-Control-Allow-Methods: GET, POST, OPTIONS`r`n" +
            "Access-Control-Allow-Headers: Content-Type`r`n" +
            "Access-Control-Allow-Private-Network: true`r`n" +
            "Cache-Control: no-store`r`n" +
            "Connection: close`r`n`r`n"
  $hb = [System.Text.Encoding]::ASCII.GetBytes($header)
  $stream.Write($hb, 0, $hb.Length)
  if ($bytes.Length -gt 0) { $stream.Write($bytes, 0, $bytes.Length) }
  $stream.Flush()
}

function Send-Text($stream, [int]$status, [string]$contentType, [string]$text) {
  Send-Bytes $stream $status $contentType ([System.Text.Encoding]::UTF8.GetBytes($text))
}

function Send-Json($stream, [int]$status, $obj) {
  $json = if ($null -eq $obj) { 'null' } else { $obj | ConvertTo-Json -Depth 100 -Compress }
  Send-Text $stream $status 'application/json; charset=utf-8' $json
}

function Read-Request($stream) {
  $buffer = New-Object byte[] 16384
  $ms = New-Object System.IO.MemoryStream
  $headerEnd = -1
  while ($headerEnd -lt 0) {
    $n = $stream.Read($buffer, 0, $buffer.Length)
    if ($n -le 0) { break }
    $ms.Write($buffer, 0, $n)
    $arr = $ms.ToArray()
    for ($i = 0; $i -le $arr.Length - 4; $i++) {
      if ($arr[$i] -eq 13 -and $arr[$i + 1] -eq 10 -and $arr[$i + 2] -eq 13 -and $arr[$i + 3] -eq 10) {
        $headerEnd = $i + 4
        break
      }
    }
  }
  $all = $ms.ToArray()
  if ($headerEnd -lt 0) { return $null }
  $headerText = [System.Text.Encoding]::ASCII.GetString($all, 0, $headerEnd)
  $lines = $headerText -split "`r`n"
  $requestLine = $lines[0]
  $parts = $requestLine -split ' '
  $method = $parts[0]
  $path = if ($parts.Length -ge 2) { $parts[1] } else { '/' }

  $contentLength = 0
  foreach ($line in $lines) {
    if ($line -match '^(?i)Content-Length:\s*(\d+)') { $contentLength = [int]$matches[1] }
  }

  $bodyBytes = New-Object System.Collections.Generic.List[byte]
  if ($all.Length -gt $headerEnd) {
    for ($i = $headerEnd; $i -lt $all.Length; $i++) { $bodyBytes.Add($all[$i]) }
  }
  while ($bodyBytes.Count -lt $contentLength) {
    $n = $stream.Read($buffer, 0, $buffer.Length)
    if ($n -le 0) { break }
    for ($i = 0; $i -lt $n; $i++) { $bodyBytes.Add($buffer[$i]) }
  }
  $bodyText = ''
  if ($bodyBytes.Count -gt 0) {
    $bodyText = [System.Text.Encoding]::UTF8.GetString($bodyBytes.ToArray())
  }
  return @{ Method = $method; Path = $path; Body = $bodyText }
}

function Read-DataFile {
  try {
    if (Test-Path -LiteralPath $DataFile) {
      $raw = Get-Content -LiteralPath $DataFile -Raw -Encoding UTF8
      if ($raw -and $raw.Trim().Length -gt 0) { return $raw }
    }
  } catch { }
  return $null
}

function Write-DataFile([string]$text) {
  Show-FileForWrite $DataFile
  [System.IO.File]::WriteAllText($DataFile, $text, (New-Object System.Text.UTF8Encoding($false)))
  Hide-File $DataFile
}

function Read-LicFile {
  try {
    if (Test-Path -LiteralPath $LicFile) {
      $raw = Get-Content -LiteralPath $LicFile -Raw -Encoding UTF8
      if ($raw -and $raw.Trim().Length -gt 0) { return $raw }
    }
  } catch { }
  return $null
}

# Generic hidden text files: the signed user pack (.usr) and the device
# registration (.dev) live next to the database and stay hidden.
function Read-HiddenText([string]$Path) {
  try {
    if (Test-Path -LiteralPath $Path) {
      # .NET reads hidden files directly; Get-Content needs -Force and can
      # fail on files protected by security software.
      $raw = [System.IO.File]::ReadAllText($Path, [System.Text.Encoding]::UTF8)
      if ($raw -and $raw.Trim().Length -gt 0) { return $raw }
    }
  } catch { }
  return $null
}

function Write-HiddenText([string]$Path, [string]$text) {
  Show-FileForWrite $Path
  [System.IO.File]::WriteAllText($Path, $text, (New-Object System.Text.UTF8Encoding($false)))
  Hide-File $Path
}

# Telegram credentials and relay helpers stay in a server-side companion file.
$RelayPath = Join-Path $ScriptDir 'EAC Telegram Relay.ps1'
if (Test-Path -LiteralPath $RelayPath) { . $RelayPath }

# One-button remote updater. It only replaces program files, never shop data.
$UpdateScript = Join-Path $ScriptDir 'EAC Update.ps1'
if (Test-Path -LiteralPath $UpdateScript) { . $UpdateScript }

# The signed user pack is a SLU1.<base64url> string. The server cannot
# verify the ECDSA signature (the private key never ships), but it can
# reject malformed packs and packs built for a different device.
function Test-UserPack([string]$pack, [ref]$deviceCodeOut) {
  $deviceCodeOut.Value = ''
  try {
    if (-not $pack.StartsWith('SLU1.')) { return $false }
    $b64 = $pack.Substring(5).Replace('-', '+').Replace('_', '/')
    $pad = (4 - ($b64.Length % 4)) % 4
    if ($pad -gt 0) { $b64 = $b64 + ('=' * $pad) }
    $jsonText = [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($b64))
    $outer = $jsonText | ConvertFrom-Json
    if (-not $outer -or -not $outer.body -or -not $outer.sig) { return $false }
    $payload = $outer.body | ConvertFrom-Json
    if (-not $payload -or $payload.kind -ne 'sl-users' -or [int]$payload.v -ne 1) { return $false }
    if ($null -eq $payload.users) { return $false }
    $code = ([string]$payload.deviceCode).ToLowerInvariant()
    if ($code -notmatch '^[0-9a-f]{24}$') { return $false }
    $deviceCodeOut.Value = $code
    return $true
  } catch {
    return $false
  }
}

$listener = $null
try {
  $listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $Port)
  $listener.Start()
  Write-ServerLog ('listening on 127.0.0.1:' + $Port + '; pid=' + $PID)
} catch {
  # Another copy is already running; leave it alone.
  Write-ServerLog ('port ' + $Port + ' is already in use; this copy will exit. ' + $_.Exception.Message)
  exit 0
}

$quit = $false
try {
  while ($true) {
    $client = $listener.AcceptTcpClient()
    try {
      $stream = $client.GetStream()
      $stream.ReadTimeout = 15000
      $req = Read-Request $stream
      if ($null -eq $req) { $client.Close(); continue }

      $method = $req.Method
      $path = ($req.Path -split '\?')[0]

      if ($method -eq 'OPTIONS') {
        Send-Bytes $stream 204 'text/plain' ([byte[]]@())
      }
      elseif ($path -eq '/api/ping') {
        Send-Json $stream 200 @{ ok = $true; app = 'EAC'; build = $ServerBuild; port = $Port; dataFile = $DataFile; machine = $MachineId; appPath = $AppPath; pid = $PID; ps = $PSVersionTable.PSVersion.ToString() }
      }
      elseif ($path -eq '/api/quit' -and $method -eq 'POST') {
        Send-Json $stream 200 @{ ok = $true }
        $quit = $true
      }
      elseif ($path -eq '/api/state' -and $method -eq 'GET') {
        $raw = Read-DataFile
        if ($raw) {
          # Return the stored object as-is (it already has { data, savedAt }).
          Send-Text $stream 200 'application/json; charset=utf-8' $raw
        } else {
          Send-Json $stream 200 @{ data = $null }
        }
      }
      elseif ($path -eq '/api/state' -and $method -eq 'POST') {
        if ($req.Body -and $req.Body.Trim().Length -gt 0) {
          Write-DataFile $req.Body
          Send-Json $stream 200 @{ ok = $true; savedAt = (Get-Date).ToString('o') }
        } else {
          Send-Json $stream 400 @{ ok = $false; error = 'empty body' }
        }
      }
      elseif ($path -eq '/api/license' -and $method -eq 'GET') {
        $raw = Read-LicFile
        if ($raw) {
          Send-Text $stream 200 'application/json; charset=utf-8' ('{"license":' + $raw + '}')
        } else {
          Send-Json $stream 200 @{ license = $null }
        }
      }
      elseif ($path -eq '/api/license' -and $method -eq 'POST') {
        if ($req.Body -and $req.Body.Trim().Length -gt 0) {
          Show-FileForWrite $LicFile
          [System.IO.File]::WriteAllText($LicFile, $req.Body, (New-Object System.Text.UTF8Encoding($false)))
          Hide-File $LicFile
          Send-Json $stream 200 @{ ok = $true }
        } else {
          Send-Json $stream 400 @{ ok = $false; error = 'empty body' }
        }
      }
      elseif ($path -eq '/api/users' -and $method -eq 'GET') {
        $pack = Read-HiddenText $UsersFile
        if ($pack) {
          Send-Json $stream 200 @{ ok = $true; pack = $pack }
        } else {
          Send-Json $stream 200 @{ ok = $true; pack = $null }
        }
      }
      elseif ($path -eq '/api/users' -and $method -eq 'POST') {
        $pack = ''
        try {
          $obj = $req.Body | ConvertFrom-Json
          if ($obj -and $obj.pack) { $pack = [string]$obj.pack }
        } catch { }
        if (-not $pack) { $pack = [string]$req.Body }
        $pack = $pack.Trim()
        $packDevice = ''
        $ref = [ref]$packDevice
        if (-not (Test-UserPack $pack $ref)) {
          Write-ServerLog 'POST /api/users rejected: invalid pack'
          Send-Json $stream 400 @{ ok = $false; error = 'invalid user pack' }
        } else {
          $knownDevice = ''
          $devRaw = Read-HiddenText $DeviceFile
          if ($devRaw) {
            try {
              $devObj = $devRaw | ConvertFrom-Json
              if ($devObj -and $devObj.deviceCode) { $knownDevice = ([string]$devObj.deviceCode).ToLowerInvariant() }
            } catch { }
          }
          if ($knownDevice -and $knownDevice -ne $packDevice) {
            Write-ServerLog ('POST /api/users rejected: pack device ' + $packDevice + ' does not match ' + $knownDevice)
            Send-Json $stream 400 @{ ok = $false; error = 'user pack belongs to another device' }
          } else {
            Write-HiddenText $UsersFile $pack
            Write-ServerLog ('POST /api/users stored for device ' + $packDevice)
            Send-Json $stream 200 @{ ok = $true; deviceCode = $packDevice }
          }
        }
      }
      elseif ($path -eq '/api/device' -and $method -eq 'GET') {
        $raw = Read-HiddenText $DeviceFile
        if ($raw) {
          try {
            $dev = $raw | ConvertFrom-Json
            Send-Json $stream 200 @{ ok = $true; deviceCode = [string]$dev.deviceCode; deviceLabel = [string]$dev.deviceLabel; at = [string]$dev.at }
          } catch {
            Send-Json $stream 200 @{ ok = $false; deviceCode = $null }
          }
        } else {
          Send-Json $stream 200 @{ ok = $true; deviceCode = $null }
        }
      }
      elseif ($path -eq '/api/device' -and $method -eq 'POST') {
        $code = ''
        $label = ''
        try {
          $obj = $req.Body | ConvertFrom-Json
          if ($obj) {
            if ($obj.deviceCode) { $code = ([string]$obj.deviceCode).ToLowerInvariant() }
            if ($obj.deviceLabel) { $label = [string]$obj.deviceLabel }
          }
        } catch { }
        if ($code -notmatch '^[0-9a-f]{24}$') {
          Send-Json $stream 400 @{ ok = $false; error = 'invalid device code' }
        } else {
          $dev = @{ deviceCode = $code; deviceLabel = $label; at = (Get-Date).ToString('o') }
          Write-HiddenText $DeviceFile ($dev | ConvertTo-Json -Depth 5 -Compress)
          Write-ServerLog ('POST /api/device registered ' + $code + ' (' + $label + ')')
          Send-Json $stream 200 @{ ok = $true }
        }
      }
      elseif ($path -like '/api/telegram/*' -and (Handle-TelegramRequest $req $method $path $stream)) {
        # Relay handled the response.
      }
      elseif ($path -like '/api/update/*' -and (Handle-EacUpdateRequest $req $method $path $stream ([ref]$quit))) {
        # Updater handled the response.
      }
      elseif ($method -eq 'GET' -and ($path -eq '/' -or $path -eq '/index.html' -or $path -like '*.html')) {
        if (Test-Path -LiteralPath $AppPath) {
          $bytes = [System.IO.File]::ReadAllBytes($AppPath)
          Send-Bytes $stream 200 'text/html; charset=utf-8' $bytes
        } else {
          Write-ServerLog ('app file not found: ' + $AppPath)
          Send-Text $stream 404 'text/plain; charset=utf-8' 'App file not found next to the server.'
        }
      }
      else {
        Send-Json $stream 404 @{ ok = $false; error = 'not found' }
      }
    } catch {
      Write-ServerLog ('request error: ' + $_.Exception.Message)
      try { Send-Json $stream 500 @{ ok = $false; error = $_.Exception.Message } } catch { }
    } finally {
      try { $client.Close() } catch { }
    }
    if ($quit) { break }
  }
} finally {
  if ($listener) { try { $listener.Stop() } catch { } }
  Write-ServerLog 'stopped'
}
