# ============================================================================
#  EAC POS v2.1 - one-button remote updater (dot-sourced by EAC Server.ps1)
#  Only program files are replaced. The hidden database, licence, users,
#  device and chat files are never read, written or deleted here.
# ============================================================================

$script:UpdatePublicKey = '<RSAKeyValue><Modulus>+6s3+xjkXJt/bI2MwBFmhQp3Pw3WuUpI03lr8XOzd/r+O5HQDH7msyEbHKvYC0j3nY8JvkPX/nKrsKNioxUqyjuC1i6qwwzDv+aBZTiNNDC7Isxh2azSB9dMcFdiFoG+7oKJBDFRzXCek5w+H/Xk1Ewx0VZWg2fi0WPDym1Sy/u6GGIa8oRiM45bsdExmcKgIRoXJ8zp+539ZMtNwriwJsRHF/x5//OZVZpjvPX/XornUMwBKmkBRfSbHTQgS8hLs3NRTElpf253unNW7F/qAXqRrg79ZnLVVm1rX9KJXg0AEz0X2u4/ear8mN5llzyV03MabTIeTSU+fGSvn9WjOQ==</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>'

function Read-EacUpdateConfig {
  $cfgPath = Join-Path $ScriptDir 'EAC Update Config.json'
  $cfg = @{ updateUrl = '' }
  if (Test-Path -LiteralPath $cfgPath) {
    try {
      $obj = [System.IO.File]::ReadAllText($cfgPath, [System.Text.Encoding]::UTF8) | ConvertFrom-Json
      if ($null -ne $obj -and $null -ne $obj.updateUrl) { $cfg.updateUrl = [string]$obj.updateUrl }
    } catch { }
  }
  return $cfg
}

function Test-EacUpdateUrl([string]$url) {
  try {
    $uri = [Uri]$url
    if ($uri.Scheme -eq 'https') { return $true }
    if ($uri.Scheme -eq 'http' -and $uri.Host -in @('127.0.0.1', 'localhost')) { return $true }
  } catch { }
  return $false
}

function Get-EacUpdateInfo {
  $cfg = Read-EacUpdateConfig
  $url = ([string]$cfg.updateUrl).Trim()
  if (-not $url) {
    return @{ ok = $true; configured = $false; available = $false; currentBuild = $ServerBuild }
  }
  if (-not (Test-EacUpdateUrl $url)) {
    return @{ ok = $false; error = 'Update URL must use HTTPS' }
  }
  try {
    # Cache-bust so a freshly published update.json is seen immediately
    # instead of waiting for the raw.githubusercontent.com CDN to expire.
    $sep = if ($url.Contains('?')) { '&' } else { '?' }
    $requestUrl = $url + $sep + '_t=' + [DateTime]::UtcNow.Ticks
    $oldProgress = $ProgressPreference
    $ProgressPreference = 'SilentlyContinue'
    $res = Invoke-WebRequest -Uri $requestUrl -UseBasicParsing -TimeoutSec 30
    $ProgressPreference = $oldProgress
    $meta = $res.Content | ConvertFrom-Json
    $build = [int]$meta.build
    return @{
      ok = $true
      configured = $true
      available = ($build -gt [int]$ServerBuild)
      build = $build
      currentBuild = $ServerBuild
      version = [string]$meta.version
      downloadUrl = [string]$meta.url
      sha256 = [string]$meta.sha256
      signature = [string]$meta.signature
      notes = [string]$meta.notes
    }
  } catch {
    return @{ ok = $false; error = ('Cannot read update information: ' + $_.Exception.Message) }
  }
}

function Test-EacUpdatePackage($info, [string]$zipPath) {
  $hash = (Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($hash -ne ([string]$info.sha256).ToLowerInvariant()) { return $false }
  try {
    $hex = $hash
    $hashBytes = New-Object byte[] 32
    for ($i = 0; $i -lt 32; $i++) { $hashBytes[$i] = [Convert]::ToByte($hex.Substring($i * 2, 2), 16) }
    $sigBytes = [Convert]::FromBase64String([string]$info.signature)
    $rsa = New-Object System.Security.Cryptography.RSACryptoServiceProvider
    $rsa.FromXmlString($script:UpdatePublicKey)
    $valid = $rsa.VerifyHash($hashBytes, $sigBytes, 'SHA256')
    $rsa.Dispose()
    return [bool]$valid
  } catch { return $false }
}

function Install-EacUpdate($info) {
  $work = Join-Path $env:TEMP ('EAC Update\' + [string]$info.build)
  $staging = Join-Path $work 'unpacked'
  $zipPath = Join-Path $work 'update.zip'
  try {
    New-Item -ItemType Directory -Path $work -Force | Out-Null
    if (Test-Path -LiteralPath $staging) { Remove-Item -LiteralPath $staging -Recurse -Force }
    New-Item -ItemType Directory -Path $staging -Force | Out-Null

    if (-not (Test-EacUpdateUrl ([string]$info.downloadUrl))) { throw 'Package URL must use HTTPS' }
    $oldProgress = $ProgressPreference
    $ProgressPreference = 'SilentlyContinue'
    Invoke-WebRequest -Uri ([string]$info.downloadUrl) -OutFile $zipPath -UseBasicParsing -TimeoutSec 120
    $ProgressPreference = $oldProgress

    if (-not (Test-EacUpdatePackage $info $zipPath)) { throw 'Package failed hash or signature verification' }

    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::ExtractToDirectory($zipPath, $staging)
    $manifestPath = Join-Path $staging 'manifest.json'
    if (-not (Test-Path -LiteralPath $manifestPath)) { throw 'Update package has no manifest.json' }
    $manifest = [System.IO.File]::ReadAllText($manifestPath, [System.Text.Encoding]::UTF8) | ConvertFrom-Json
    $htmlName = [string]$manifest.html
    if (-not $htmlName -or -not (Test-Path -LiteralPath (Join-Path $staging $htmlName))) { throw 'Update HTML is missing' }

    $files = @($manifest.files | ForEach-Object { [string]$_ })
    if (-not $files.Count) { throw 'Update manifest has no files' }

    # One-time migration: preserve the token already on this PC before the
    # old relay file (which used to contain it) is replaced by the update.
    $secretLocal = Join-Path $ScriptDir 'EAC Telegram Secret.txt'
    if (-not (Test-Path -LiteralPath $secretLocal)) {
      $oldRelay = Join-Path $ScriptDir 'EAC Telegram Relay.ps1'
      if (Test-Path -LiteralPath $oldRelay) {
        $oldText = [System.IO.File]::ReadAllText($oldRelay, [System.Text.Encoding]::UTF8)
        $oldMatch = [regex]::Match($oldText, '\$TelegramToken\s*=\s*''([^'']+)''')
        if ($oldMatch.Success -and $oldMatch.Groups[1].Value -match '^\d+:[A-Za-z0-9_\-]+$') {
          [System.IO.File]::WriteAllText($secretLocal, $oldMatch.Groups[1].Value, (New-Object System.Text.UTF8Encoding($false)))
        }
      }
    }

    $backup = Join-Path $work ('backup-' + (Get-Date).ToString('yyyyMMdd-HHmmss'))
    New-Item -ItemType Directory -Path $backup -Force | Out-Null
    $copied = @()
    foreach ($name in $files) {
      if ($name -match '\.(lic|usr|dev|tlg)$') { continue }
      if ($name -match '^[0-9a-fA-F\-]{36}\.dat$') { continue }
      if ($name -eq 'EAC Update Config.json' -or $name -eq 'EAC Update.ps1' -or $name -eq 'manifest.json') { continue }
      if ($name -eq 'EAC Telegram Secret.txt') { continue }
      $source = Join-Path $staging $name
      if (-not (Test-Path -LiteralPath $source)) { throw ('Missing update file: ' + $name) }
      $target = Join-Path $ScriptDir $name
      $parent = Split-Path -Parent $target
      if ($parent -and -not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
      if (Test-Path -LiteralPath $target) {
        $bak = Join-Path $backup $name
        $bakParent = Split-Path -Parent $bak
        if ($bakParent -and -not (Test-Path -LiteralPath $bakParent)) { New-Item -ItemType Directory -Path $bakParent -Force | Out-Null }
        Copy-Item -LiteralPath $target -Destination $bak -Force
      }
      Copy-Item -LiteralPath $source -Destination $target -Force
      $copied += $name
    }

    # Restart the local server so the new build is actually loaded.
    $serverFile = Join-Path $ScriptDir 'EAC Server.ps1'
    $restart = 'timeout /t 2 /nobreak >nul & start "" /min powershell.exe -NoProfile -ExecutionPolicy Bypass -File "' + $serverFile + '"'
    Start-Process -FilePath "$env:windir\System32\cmd.exe" -ArgumentList @('/c', $restart) -WindowStyle Hidden | Out-Null

    Write-ServerLog ('update installed; build=' + [string]$info.build + '; files=' + ($copied -join ', ') + '; backup=' + $backup)
    return @{ ok = $true; build = [int]$info.build; version = [string]$info.version; backup = $backup }
  } catch {
    Write-ServerLog ('update failed: ' + $_.Exception.Message)
    return @{ ok = $false; error = $_.Exception.Message }
  }
}

function Handle-EacUpdateRequest($Request, [string]$Method, [string]$Path, $Stream, [ref]$QuitFlag) {
  if ($Method -ne 'POST') { return $false }

  if ($Path -eq '/api/update/check') {
    $info = Get-EacUpdateInfo
    Send-Json $Stream 200 $info
    return $true
  }

  if ($Path -eq '/api/update/install') {
    $info = Get-EacUpdateInfo
    if (-not $info.ok) { Send-Json $Stream 200 $info; return $true }
    if (-not $info.configured) {
      Send-Json $Stream 200 @{ ok = $false; error = 'Update URL is not configured' }
      return $true
    }
    if (-not $info.available) {
      Send-Json $Stream 200 @{ ok = $false; error = 'Already up to date' }
      return $true
    }
    $result = Install-EacUpdate $info
    if ($result.ok) { $QuitFlag.Value = $true }
    Send-Json $Stream 200 $result
    return $true
  }

  return $false
}
