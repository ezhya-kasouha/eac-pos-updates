@echo off
setlocal EnableExtensions
title EAC - Create Desktop Shortcut
cd /d "%~dp0"

rem Output folder is the first argument; when called from tests we pass it explicitly.
set "EAC_OUT=%~1"
if "%EAC_OUT%"=="" set "EAC_OUT=%USERPROFILE%\Desktop"

rem The logo ships inside this package, so the shortcut works offline.
set "EAC_PNG=%~dp0logo.png"
if not exist "%EAC_PNG%" (
  echo.
  echo Logo not found in this package: %EAC_PNG%
  echo Restore logo.png next to this file, then run again.
  echo.
  if "%~1"=="" pause
  exit /b 1
)
if not exist "%~dp0EAC Launcher.cmd" (
  echo EAC Launcher.cmd is missing from this folder.
  if "%~1"=="" pause
  exit /b 1
)

set "EAC_PS=%TEMP%\EAC-shortcut-%RANDOM%.ps1"
>  "%EAC_PS%" echo $ErrorActionPreference='Stop'
>> "%EAC_PS%" echo $png = $env:EAC_PNG_PATH
>> "%EAC_PS%" echo $folder = $env:EAC_SRC_FOLDER
>> "%EAC_PS%" echo $desktopOut = $env:EAC_DESKTOP_OUT
>> "%EAC_PS%" echo if (-not $png -or -not $folder -or -not $desktopOut) { throw 'Missing env vars' }
>> "%EAC_PS%" echo $png = $png.TrimEnd([char]34,[char]92)
>> "%EAC_PS%" echo $folder = $folder.TrimEnd([char]34,[char]92)
>> "%EAC_PS%" echo $desktopOut = $desktopOut.TrimEnd([char]34,[char]92)
>> "%EAC_PS%" echo $target = Join-Path $folder 'EAC Launcher.cmd'
>> "%EAC_PS%" echo if (-not (Test-Path -LiteralPath $target)) { throw ('Missing: ' + $target) }
>> "%EAC_PS%" echo $iconDir = Join-Path $env:LOCALAPPDATA 'EAC'
>> "%EAC_PS%" echo if (-not (Test-Path -LiteralPath $iconDir)) { New-Item -ItemType Directory -Path $iconDir -Force ^| Out-Null }
>> "%EAC_PS%" echo $ico = Join-Path $iconDir 'EAC.ico'
>> "%EAC_PS%" echo Add-Type -AssemblyName System.Drawing
>> "%EAC_PS%" echo $img = [System.Drawing.Image]::FromFile($png)
>> "%EAC_PS%" echo $bmp = New-Object System.Drawing.Bitmap 256,256
>> "%EAC_PS%" echo $g = [System.Drawing.Graphics]::FromImage($bmp)
>> "%EAC_PS%" echo $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
>> "%EAC_PS%" echo $g.DrawImage($img, 0, 0, 256, 256)
>> "%EAC_PS%" echo $ms = New-Object System.IO.MemoryStream
>> "%EAC_PS%" echo $bmp.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png)
>> "%EAC_PS%" echo $g.Dispose()
>> "%EAC_PS%" echo $bmp.Dispose()
>> "%EAC_PS%" echo $img.Dispose()
>> "%EAC_PS%" echo $pngBytes = $ms.ToArray()
>> "%EAC_PS%" echo $ms.Dispose()
>> "%EAC_PS%" echo $hdr = New-Object byte[] 22
>> "%EAC_PS%" echo $hdr[2] = 1
>> "%EAC_PS%" echo $hdr[4] = 1
>> "%EAC_PS%" echo $hdr[10] = 1
>> "%EAC_PS%" echo $hdr[11] = 0
>> "%EAC_PS%" echo $hdr[12] = 32
>> "%EAC_PS%" echo [BitConverter]::GetBytes([int]$pngBytes.Length).CopyTo($hdr, 14)
>> "%EAC_PS%" echo [BitConverter]::GetBytes([int]22).CopyTo($hdr, 18)
>> "%EAC_PS%" echo [IO.File]::WriteAllBytes($ico, $hdr + $pngBytes)
>> "%EAC_PS%" echo $ws = New-Object -ComObject WScript.Shell
>> "%EAC_PS%" echo $lnk = Join-Path $desktopOut 'EAC.lnk'
>> "%EAC_PS%" echo $s = $ws.CreateShortcut($lnk)
>> "%EAC_PS%" echo $s.TargetPath = $target
>> "%EAC_PS%" echo $s.WorkingDirectory = $folder
>> "%EAC_PS%" echo $s.IconLocation = $ico + ',0'
>> "%EAC_PS%" echo $s.Description = 'EAC'
>> "%EAC_PS%" echo $s.Save()
>> "%EAC_PS%" echo Write-Host ('Created: ' + $lnk)

set "EAC_PNG_PATH=%EAC_PNG%"
set "EAC_SRC_FOLDER=%~dp0"
set "EAC_DESKTOP_OUT=%EAC_OUT%"
powershell -NoProfile -ExecutionPolicy Bypass -File "%EAC_PS%"
set "EAC_RC=%ERRORLEVEL%"
del /q "%EAC_PS%" >nul 2>nul
if not "%EAC_RC%"=="0" (
  echo.
  echo Shortcut creation failed. Error code: %EAC_RC%
  if "%~1"=="" pause
  exit /b %EAC_RC%
)
echo.
echo Done. Desktop shortcut created: EAC.lnk
echo Your data and activation are unchanged.
echo.
if "%~1"=="" pause
exit /b 0
