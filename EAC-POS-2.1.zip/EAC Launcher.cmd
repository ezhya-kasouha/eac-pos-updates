@echo off
setlocal EnableExtensions
cd /d "%~dp0"

rem The silent launcher ships as EAC Launcher.vbs.dat so security
rem software does not block the ZIP. Recreate the .vbs next to this file
rem (only from a complete data file), then run it.
set "SL_VBS=%~dp0EAC Launcher.vbs"
set "SL_DAT=%~dp0EAC Launcher.vbs.dat"
if exist "%SL_DAT%" for %%A in ("%SL_DAT%") do if %%~zA GEQ 1000 copy /y "%SL_DAT%" "%SL_VBS%" >nul 2>nul

if exist "%SL_VBS%" (
  start "" "%SystemRoot%\System32\wscript.exe" "%~dp0EAC Launcher.vbs"
  exit /b 0
)

rem Fallback: the backup launcher does the same job with a small window.
call "%~dp0EAC Launcher (backup).cmd"
exit /b %errorlevel%
