# ============================================================================
#  EAC Telegram support relay (dot-sourced by EAC Server.ps1)
#  Bot credentials stay in this server-side file; the browser never sees them.
# ============================================================================

# Bot token lives in a local-only secret file. It is excluded from every
# update package so the public GitHub repository never contains a credential.
$SecretPath = Join-Path $ScriptDir 'EAC Telegram Secret.txt'
$TelegramToken = ''
if (Test-Path -LiteralPath $SecretPath) {
  $TelegramToken = ([System.IO.File]::ReadAllText($SecretPath, [System.Text.Encoding]::UTF8)).Trim()
}
$TelegramChatId = '6803806042'
$TelegramOwnerId = 6803806042
try {
  [System.Net.ServicePointManager]::SecurityProtocol =
    [System.Net.ServicePointManager]::SecurityProtocol -bor [System.Net.SecurityProtocolType]::Tls12
} catch { }
[System.Net.ServicePointManager]::Expect100Continue = $false

# Chat rows older than 24 hours are dropped on every read and write.
function Prune-EacChatMessages($messages, $clearedAt) {
  $cutoff = (Get-Date).ToUniversalTime().AddHours(-24)
  $cleared = $null
  if ($clearedAt) {
    try { $cleared = [DateTimeOffset]::Parse([string]$clearedAt).UtcDateTime } catch { $cleared = $null }
  }
  $kept = @()
  foreach ($m in @($messages)) {
    if ($null -eq $m) { continue }
    $at = $null
    try { if ($null -ne $m.at) { $at = [DateTimeOffset]::Parse([string]$m.at).UtcDateTime } } catch { $at = $null }
    if ($null -eq $at) { continue }
    if ($at -lt $cutoff) { continue }
    if ($null -ne $cleared -and $at -le $cleared) { continue }
    $kept += $m
  }
  return $kept
}

function Read-ChatState {
  $state = @{ primed = $false; lastUpdateId = [long]0; delivered = @(); deviceCode = ''; messages = @(); clearedAt = '' }
  $raw = Read-HiddenText $ChatFile
  if (-not $raw) { return $state }
  try {
    $obj = $raw | ConvertFrom-Json
    if ($null -eq $obj) { return $state }
    if ($null -ne $obj.primed) { $state.primed = [bool]$obj.primed }
    if ($null -ne $obj.lastUpdateId) { $state.lastUpdateId = [long]$obj.lastUpdateId }
    if ($null -ne $obj.delivered) { $state.delivered = @($obj.delivered | ForEach-Object { [string]$_ }) }
    if ($null -ne $obj.deviceCode) { $state.deviceCode = [string]$obj.deviceCode }
    if ($null -ne $obj.clearedAt) { $state.clearedAt = [string]$obj.clearedAt }
    if ($null -ne $obj.messages) { $state.messages = @(Prune-EacChatMessages $obj.messages $state.clearedAt) }
  } catch { }
  return $state
}

function Write-ChatState($state) {
  if (-not $state.ContainsKey('clearedAt')) { $state.clearedAt = '' }
  $state.delivered = @($state.delivered | Select-Object -Last 200)
  $state.messages = @(Prune-EacChatMessages $state.messages $state.clearedAt | Select-Object -Last 100)
  Write-HiddenText $ChatFile ($state | ConvertTo-Json -Depth 20 -Compress)
}

function Normalize-EacDeviceCode([string]$code) {
  if (-not $code) { return '' }
  return ([string]$code -replace '[^0-9A-Fa-f]', '').ToUpperInvariant()
}

function Get-EacCodeFromText([string]$text) {
  if (-not $text) { return '' }
  $match = [regex]::Match([string]$text, 'Device:\s*([0-9A-Fa-f-]{8,})')
  if (-not $match.Success) { return '' }
  return Normalize-EacDeviceCode $match.Groups[1].Value
}

# Only accept an owner message when it replies to this device's support text,
# or when its first word is the device code. Ordinary chat in the owner's bot
# must never unlock or add users to an unrelated machine.
function Get-EacReplyText($message, [string]$deviceCode) {
  if ($null -eq $message -or -not $deviceCode) { return '' }
  try {
    $replyTo = $message.reply_to_message
    if ($null -ne $replyTo) {
      $original = [string]$replyTo.text
      if (-not $original) { $original = [string]$replyTo.caption }
      $code = Get-EacCodeFromText $original
      if ($code -and $code -eq $deviceCode) {
        $answer = [string]$message.text
        if (-not $answer) { $answer = [string]$message.caption }
        return $answer.Trim()
      }
    }
    $text = ([string]$message.text).Trim()
    if (-not $text) { $text = ([string]$message.caption).Trim() }
    if (-not $text) { return '' }
    $parts = $text -split '\s+', 2
    if ($parts.Count -ge 2) {
      $code = Normalize-EacDeviceCode $parts[0]
      if ($code -and $code -eq $deviceCode) { return $parts[1].Trim() }
    }
  } catch { }
  return ''
}

function Invoke-Telegram([string]$method, $parameters, [bool]$isPost) {
  $url = 'https://api.telegram.org/bot' + $TelegramToken + '/' + $method
  $bodyBytes = $null
  if ($isPost) {
    $json = $parameters | ConvertTo-Json -Depth 10 -Compress
    $bodyBytes = [System.Text.Encoding]::UTF8.GetBytes($json)
  } else {
    $parts = @()
    foreach ($key in $parameters.Keys) {
      $parts += ([uri]::EscapeDataString($key) + '=' + [uri]::EscapeDataString([string]$parameters[$key]))
    }
    if ($parts.Count -gt 0) { $url = $url + '?' + ($parts -join '&') }
  }

  $req = [System.Net.HttpWebRequest]::Create($url)
  # Proxy auto-detection makes api.telegram.org hang on some machines.
  # All request properties must be set before GetRequestStream() is called.
  $req.Proxy = $null
  $req.Timeout = 10000
  $req.ReadWriteTimeout = 10000
  $req.Method = if ($isPost) { 'POST' } else { 'GET' }
  if ($isPost) {
    $req.ContentType = 'application/json; charset=utf-8'
    $req.ContentLength = $bodyBytes.Length
    $stream = $req.GetRequestStream()
    $stream.Write($bodyBytes, 0, $bodyBytes.Length)
    $stream.Close()
  }

  $res = $req.GetResponse()
  $reader = New-Object System.IO.StreamReader($res.GetResponseStream(), [System.Text.Encoding]::UTF8)
  $text = $reader.ReadToEnd()
  $reader.Close()
  $res.Close()
  return ($text | ConvertFrom-Json)
}

function Send-EacTelegram([string]$text) {
  try {
    $result = Invoke-Telegram 'sendMessage' @{
      chat_id = $TelegramChatId
      text = $text
      disable_web_page_preview = $true
    } $true
    return @{ ok = [bool]$result.ok; error = '' }
  } catch {
    return @{ ok = $false; error = $_.Exception.Message }
  }
}

function Send-EacTelegramChunked([string]$text) {
  $max = 3500
  if ($text.Length -le $max) { return Send-EacTelegram $text }
  $parts = [math]::Ceiling($text.Length / $max)
  $allOk = $true
  for ($i = 0; $i -lt $parts; $i++) {
    $start = $i * $max
    $len = [math]::Min($max, $text.Length - $start)
    $chunk = "($($i + 1)/$parts) " + $text.Substring($start, $len)
    $one = Send-EacTelegram $chunk
    if (-not $one.ok) { $allOk = $false }
  }
  return @{ ok = $allOk; error = '' }
}

function Format-EacDeviceCode([string]$code) {
  $hex = Normalize-EacDeviceCode $code
  if ($hex.Length -ne 24) { return $hex }
  return ($hex -replace '(.{4})(?=.)', '$1-')
}

function Get-EacUsersFromPack([string]$pack) {
  $result = @{ count = 0; names = @(); pack = $pack }
  $value = [string]$pack
  if (-not $value.StartsWith('SLU1.')) { return $result }
  try {
    $b64 = $value.Substring(5).Replace('-', '+').Replace('_', '/')
    $pad = (4 - ($b64.Length % 4)) % 4
    if ($pad -gt 0) { $b64 = $b64 + ('=' * $pad) }
    $outerText = [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($b64))
    $outer = $outerText | ConvertFrom-Json
    $body = $outer.body | ConvertFrom-Json
    if ($null -ne $body.users) {
      $result.names = @($body.users | ForEach-Object {
        $name = [string]$_.name
        if (-not $name) { $name = [string]$_.username }
        if ($_.disabled) { $name + ' (disabled)' } else { $name }
      })
      $result.count = $result.names.Count
    }
  } catch { }
  return $result
}

function Get-EacActivationText() {
  $raw = Read-HiddenText $LicFile
  if (-not $raw) { return 'Activation: not activated' }
  try {
    $lic = $raw | ConvertFrom-Json
    $kind = if ([bool]$lic.temp) { 'Temporary' } else { 'Permanent' }
    $lines = @(
      'Activation: ' + $kind,
      'Activated: ' + [string]$lic.activatedAt,
      'Expires: ' + $(if ([string]$lic.expiresAt) { [string]$lic.expiresAt } else { 'never' }),
      'Signature: ' + [string]$lic.signature
    )
    return ($lines -join "`n")
  } catch { return 'Activation: unreadable licence file' }
}

function Get-EacOwnerCommand([string]$text) {
  $value = ([string]$text).Trim()
  if (-not $value) { return '' }
  $match = [regex]::Match($value, '^(STATUS|INFO|DETAILS|PACK|USERS|HELP|حالة|مستخدمون|حزمة|مساعدة)\b', 'IgnoreCase')
  if (-not $match.Success) { return '' }
  $word = $match.Groups[1].Value.ToUpperInvariant()
  switch ($word) {
    'حالة'      { return 'INFO' }
    'مستخدمون'  { return 'USERS' }
    'حزمة'      { return 'PACK' }
    'مساعدة'    { return 'HELP' }
    default     { return $word }
  }
}

function Get-EacKnownDeviceCode([string]$stateDeviceCode) {
  $fromState = Normalize-EacDeviceCode $stateDeviceCode
  if ($fromState -match '^[0-9A-F]{24}$') { return $fromState }
  try {
    $raw = Read-HiddenText $DeviceFile
    if ($raw) {
      $obj = $raw | ConvertFrom-Json
      $fromFile = Normalize-EacDeviceCode ([string]$obj.deviceCode)
      if ($fromFile -match '^[0-9A-F]{24}$') { return $fromFile }
    }
  } catch { }
  try {
    $raw = Read-HiddenText $LicFile
    if ($raw) {
      $obj = $raw | ConvertFrom-Json
      $fromLic = Normalize-EacDeviceCode ([string]$obj.deviceCode)
      if ($fromLic -match '^[0-9A-F]{24}$') { return $fromLic }
    }
  } catch { }
  return ''
}

# Owner queries follow the same safety rule as activation payloads: a reply to
# this device's support text, or an explicit device-code prefix.
function Get-EacOwnerCommandRequest($message, [string]$stateDeviceCode, [ref]$codeOut) {
  $codeOut.Value = ''
  if ($null -eq $message) { return '' }
  # Owner-only: commands are accepted only from the owner's Telegram user in
  # the owner's chat. Other senders can never reach any command handler.
  $from = $message.from
  if ($null -eq $from -or [bool]$from.is_bot -or [long]$from.id -ne [long]$TelegramOwnerId) { return '' }
  $chat = $message.chat
  if ($null -eq $chat -or [long]$chat.id -ne [long]$TelegramChatId) { return '' }
  $raw = [string]$message.text
  if (-not $raw) { $raw = [string]$message.caption }
  $raw = $raw.Trim()
  if (-not $raw) { return '' }

  $parts = $raw -split '\s+', 2
  $prefix = Normalize-EacDeviceCode $parts[0]
  $commandText = $raw
  if ($prefix -match '^[0-9A-F]{24}$') {
    $commandText = if ($parts.Count -ge 2) { $parts[1].Trim() } else { '' }
  }
  $command = Get-EacOwnerCommand $commandText
  if (-not $command) { return '' }

  $known = Get-EacKnownDeviceCode $stateDeviceCode
  if ($command -eq 'HELP') {
    $codeOut.Value = $known
    return $command
  }

  if ($prefix -match '^[0-9A-F]{24}$') {
    if ($known -and $prefix -ne $known) { return '' }
    $codeOut.Value = $prefix
    return $command
  }

  if (-not $known) { return '' }
  $replyTo = $message.reply_to_message
  if ($null -eq $replyTo) { return '' }
  $original = [string]$replyTo.text
  if (-not $original) { $original = [string]$replyTo.caption }
  if ((Get-EacCodeFromText $original) -ne $known) { return '' }
  $codeOut.Value = $known
  return $command
}

function Get-EacOwnerCommandReply([string]$command, [string]$deviceCode, [long]$senderId = 0, [long]$chatId = 0) {
  if ($senderId -ne [long]$TelegramOwnerId -or $chatId -ne [long]$TelegramChatId) { return '' }
  $shown = Format-EacDeviceCode $deviceCode
  if ($command -eq 'HELP') {
    return "EAC BOT COMMANDS`n`nReply to a customer message, or start with the device code:`nSTATUS / INFO - activation + users + pack`nPACK / USERS - signed users pack`nHELP - this list"
  }
  $users = Get-EacUsersFromPack (Read-HiddenText $UsersFile)
  if ($command -eq 'PACK' -or $command -eq 'USERS') {
    $pack = if ($users.pack) { [string]$users.pack } else { '(no users pack stored)' }
    return 'EAC USERS PACK | Device: ' + $shown + "`n`nUsers: " + $users.count + "`n`n" + $pack
  }
  $activation = Get-EacActivationText
  $header = 'EAC CUSTOMER | Device: ' + $shown
  $lines = @($header, '', $activation, '', ('Users: ' + $users.count))
  if ($users.names.Count -gt 0) { $lines += ('Names: ' + ($users.names -join ', ')) }
  $lines += '', 'Users pack:'
  if ($users.pack) { $lines += [string]$users.pack } else { $lines += '(no users pack stored)' }
  return ($lines -join "`n")
}

function Handle-TelegramRequest($Request, [string]$Method, [string]$Path, $Stream) {
  if ($Path -eq '/api/telegram/device' -and $Method -eq 'POST') {
    $code = ''
    try {
      $obj = $Request.Body | ConvertFrom-Json
      if ($obj -and $obj.deviceCode) { $code = [string]$obj.deviceCode }
    } catch { }
    $hex = Normalize-EacDeviceCode $code
    if ($hex -notmatch '^[0-9A-F]{24}$') {
      Send-Json $Stream 400 @{ ok = $false; error = 'invalid device code' }
    } else {
      $state = Read-ChatState
      if ($state.deviceCode -ne $hex) {
        $state.deviceCode = $hex
        $state.delivered = @()
        $state.messages = @()
        Write-ChatState $state
      }
      Send-Json $Stream 200 @{ ok = $true; deviceCode = $hex }
    }
    return $true
  }

  if ($Path -eq '/api/telegram/clear' -and $Method -eq 'POST') {
    $state = Read-ChatState
    # Drain every reply still queued on Telegram so an old owner message cannot
    # be fetched again by the next poll after the program is restarted.
    try {
      $params = @{ limit = 100 }
      if ([long]$state.lastUpdateId -gt 0) { $params['offset'] = [long]$state.lastUpdateId + 1 }
      $result = Invoke-Telegram 'getUpdates' $params $false
      $updates = @()
      if ($null -ne $result -and $null -ne $result.result) { $updates = @($result.result) }
      $maxId = [long]$state.lastUpdateId
      foreach ($u in $updates) { $id = [long]$u.update_id; if ($id -gt $maxId) { $maxId = $id } }
      if ($maxId -gt [long]$state.lastUpdateId) {
        # Confirming with offset = maxId+1 removes these from Telegram's queue.
        Invoke-Telegram 'getUpdates' @{ limit = 1; offset = ($maxId + 1) } $false | Out-Null
        $state.lastUpdateId = $maxId
      }
    } catch { }
    $state.clearedAt = (Get-Date).ToString('o')
    $state.messages = @()
    $state.delivered = @()
    Write-ChatState $state
    Send-Json $Stream 200 @{ ok = $true }
    return $true
  }

  if ($Path -eq '/api/telegram/history' -and $Method -eq 'GET') {
    Send-Json $Stream 200 @{ ok = $true; messages = @((Read-ChatState).messages) }
    return $true
  }

  if ($Path -eq '/api/telegram/send' -and $Method -eq 'POST') {
    $text = ''
    $display = ''
    $log = $true
    try {
      $obj = $Request.Body | ConvertFrom-Json
      if ($obj) {
        if ($obj.text) { $text = [string]$obj.text }
        if ($obj.display) { $display = [string]$obj.display }
        if ($null -ne $obj.log) { $log = [bool]$obj.log }
      }
    } catch { }
    if (-not $text.Trim()) {
      Send-Json $Stream 400 @{ ok = $false; error = 'empty message' }
      return $true
    }
    $sent = Send-EacTelegram $text
    if ($sent.ok -and $log) {
      $state = Read-ChatState
      $state.messages = @($state.messages) + @(@{
        id = 'c' + [DateTime]::UtcNow.Ticks
        from = 'customer'
        text = $(if ($display) { $display } else { $text })
        at = (Get-Date).ToString('o')
      })
      Write-ChatState $state
    }
    Write-ServerLog ('telegram send ok=' + $sent.ok + ' log=' + $log)
    Send-Json $Stream 200 $sent
    return $true
  }

  if ($Path -eq '/api/telegram/poll' -and $Method -eq 'GET') {
    $state = Read-ChatState
    $replies = @()
    try {
      $params = @{ limit = 100 }
      if ([long]$state.lastUpdateId -gt 0) { $params['offset'] = [long]$state.lastUpdateId + 1 }
      $result = Invoke-Telegram 'getUpdates' $params $false
      $updates = @()
      if ($null -ne $result -and $null -ne $result.result) { $updates = @($result.result) }

      $maxId = [long]$state.lastUpdateId
      foreach ($update in $updates) {
        $id = [long]$update.update_id
        if ($id -gt $maxId) { $maxId = $id }
      }
      $firstPoll = -not [bool]$state.primed
      if ($maxId -gt [long]$state.lastUpdateId) { $state.lastUpdateId = $maxId }
      $state.primed = $true
      Write-ChatState $state

      # Fresh install: ignore everything already in the chat.
      if (-not $firstPoll) {
        foreach ($update in $updates) {
          $message = $update.message
          if ($null -eq $message) { continue }
          $from = $message.from
          if ($null -eq $from -or [bool]$from.is_bot -or [long]$from.id -ne [long]$TelegramOwnerId) { continue }
          $chat = $message.chat
          if ($null -eq $chat -or [long]$chat.id -ne [long]$TelegramChatId) { continue }
          $messageId = [long]$message.message_id
          if ($messageId -le 0) { continue }
          $key = [string]$messageId
          if ($state.delivered -contains $key) { continue }

          $rawText = [string]$message.text
          if (-not $rawText) { $rawText = [string]$message.caption }
          $rawText = $rawText.Trim()

          $commandDevice = ''
          $command = Get-EacOwnerCommandRequest $message ([string]$state.deviceCode) ([ref]$commandDevice)
          if ($command) {
            # Owner queries are answered by this PC's server from its hidden
            # files; they are not forwarded to the app as activation codes.
            $state.delivered = @($state.delivered) + @($key)
            $answer = Get-EacOwnerCommandReply $command $commandDevice ([long]$from.id) ([long]$chat.id)
            Send-EacTelegramChunked $answer | Out-Null
            Write-ServerLog ('telegram command ' + $command + ' for ' + $commandDevice)
            $state.messages = @($state.messages) + @(@{
              id = ('tg' + $key); from = 'owner'; text = $rawText; at = (Get-Date).ToString('o')
            })
            continue
          }

          $text = Get-EacReplyText $message ([string]$state.deviceCode)
          if (-not $text) { continue }
          $state.delivered = @($state.delivered) + @($key)
          $state.messages = @($state.messages) + @(@{
            id = ('tg' + $key); from = 'owner'; text = $text; at = (Get-Date).ToString('o')
          })
          $replies = @($replies) + @(@{ id = $messageId; text = $text })
        }
        Write-ChatState $state
      }
      Send-Json $Stream 200 @{ ok = $true; primed = $true; replies = @($replies) }
    } catch {
      Write-ServerLog ('telegram poll error: ' + $_.Exception.Message)
      Send-Json $Stream 200 @{ ok = $false; error = $_.Exception.Message; replies = @() }
    }
    return $true
  }

  return $false
}
